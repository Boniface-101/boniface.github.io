# IVMS Connect

IVMS (In-Vehicle Monitoring System) installation tracking and management application.

## Tech Stack

- **React 18** + Vite
- **Tailwind CSS** + shadcn/ui
- **React Router v6**
- **Base44 SDK** (backend/auth)
- **Recharts** (analytics)

## Setup

### Prerequisites

- Node.js 18+
- npm

### Installation

1. Clone the repository:
   ```bash
   git clone <your-repo-url>
   cd ivms-connect
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create environment file:
   ```bash
   cp .env.example .env.local
   ```

4. Fill in your Base44 credentials in `.env.local`:
   ```
   VITE_BASE44_APP_ID=your_app_id
   VITE_BASE44_APP_BASE_URL=https://your-app.base44.app
   ```

5. Run development server:
   ```bash
   npm run dev
   ```

## Available Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start dev server |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |
| `npm run lint` | Run ESLint |

## Project Structure

```
src/
├── api/              # Base44 client & entity definitions
├── components/
│   ├── ui/           # shadcn/ui components
│   ├── layout/       # AppLayout, Sidebar, TopBar, MobileNav
│   └── ...           # Shared components
├── hooks/            # Custom React hooks
├── lib/              # Utilities, auth context, i18n
├── pages/            # Page-level components
├── App.jsx           # App router
├── main.jsx          # Entry point
└── index.css         # Global styles + Tailwind
```

## Features

- Vehicle tracking & management
- GPS/IVMS installation reporting
- Multi-step installation forms with digital signatures
- Defect tracking
- Project management with handover workflows
- Analytics dashboard
- User & representative management
- Arabic/English bilingual (RTL support)
- Dark mode
