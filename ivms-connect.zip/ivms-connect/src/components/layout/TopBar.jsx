import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Menu, Bell, Globe } from 'lucide-react';
import { useI18n } from '@/lib/i18n';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';

export default function TopBar({ onMenuToggle }) {
  const { t, lang, setLang } = useI18n();
  const [user, setUser] = useState(null);
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
    base44.entities.Notification.filter({ is_read: false }).then(n => setUnread(n.length)).catch(() => {});
  }, []);

  return (
    <header className="sticky top-0 z-30 bg-card/80 backdrop-blur-lg border-b border-border px-4 h-14 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <button onClick={onMenuToggle} className="md:hidden p-2 rounded-lg hover:bg-muted">
          <Menu className="w-5 h-5" />
        </button>
        {user && (
          <p className="hidden md:block text-sm text-muted-foreground">
            {t('welcome')}, <span className="font-medium text-foreground">{user.full_name || user.email}</span>
          </p>
        )}
      </div>
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}
          className="gap-1.5 text-xs"
        >
          <Globe className="w-4 h-4" />
          {lang === 'en' ? 'عربي' : 'EN'}
        </Button>
        <Link to="/notifications" className="relative p-2 rounded-lg hover:bg-muted block">
          <Bell className="w-5 h-5" />
          {unread > 0 && (
            <span className="absolute top-1 end-1 w-4 h-4 bg-destructive text-destructive-foreground text-[10px] font-bold rounded-full flex items-center justify-center">
              {unread}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
}
