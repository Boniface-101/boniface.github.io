import { Link, useLocation } from 'react-router-dom';
import { useI18n } from '@/lib/i18n';
import { LayoutDashboard, Wrench, Car, AlertTriangle, Bell, Settings, BarChart3, ListChecks, X, Users, UserCheck, FolderKanban, FileBarChart } from 'lucide-react';

const navItems = [
  { key: 'dashboard', path: '/', icon: LayoutDashboard },
  { key: 'projects', path: '/projects', icon: FolderKanban, label: 'Projects' },
  { key: 'installations', path: '/installations', icon: Wrench },
  { key: 'vehicles', path: '/vehicles', icon: Car },
  { key: 'defects', path: '/defects', icon: AlertTriangle },
  { key: 'analytics', path: '/analytics', icon: BarChart3 },
  { key: 'project_reports', path: '/project-reports', icon: FileBarChart, label: 'Project Reports' },
  { key: 'checklist_mgmt', path: '/checklist-management', icon: ListChecks },
  { key: 'notifications', path: '/notifications', icon: Bell },
  { key: 'settings', path: '/settings', icon: Settings },
  { key: 'representatives', path: '/representatives', icon: UserCheck },
  { key: 'user_management', path: '/user-management', icon: Users },
];

export default function Sidebar({ open, onClose }) {
  const { t } = useI18n();
  const location = useLocation();

  return (
    <>
      {open && (
        <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={onClose} />
      )}
      <aside
        className={`fixed top-0 start-0 z-50 h-full w-64 bg-sidebar text-sidebar-foreground flex flex-col transform transition-transform duration-300 md:translate-x-0 ${
          open ? 'translate-x-0' : '-translate-x-full'
        } rtl:${open ? 'translate-x-0' : 'translate-x-full'} rtl:md:translate-x-0`}
      >
        <div className="flex items-center justify-between p-4 border-b border-sidebar-border">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
              <Wrench className="w-4 h-4 text-sidebar-primary-foreground" />
            </div>
            <span className="font-heading font-bold text-lg">{t('app_name')}</span>
          </div>
          <button onClick={onClose} className="md:hidden p-1 rounded hover:bg-sidebar-accent">
            <X className="w-5 h-5" />
          </button>
        </div>
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = item.path === '/'
              ? location.pathname === '/'
              : location.pathname.startsWith(item.path);
            return (
              <Link
                key={item.key}
                to={item.path}
                onClick={onClose}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                    : 'hover:bg-sidebar-accent text-sidebar-foreground/80 hover:text-sidebar-foreground'
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span>{item.label || t(item.key)}</span>
              </Link>
            );
          })}
        </nav>
        <div className="p-4 border-t border-sidebar-border">
          <p className="text-xs text-sidebar-foreground/40 text-center">Arabitra × Tamimi Global</p>
        </div>
      </aside>
    </>
  );
}
