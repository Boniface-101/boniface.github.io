import { Link, useLocation } from 'react-router-dom';
import { useI18n } from '@/lib/i18n';
import { LayoutDashboard, Wrench, Car, AlertTriangle, FolderKanban } from 'lucide-react';

const navItems = [
  { key: 'dashboard', path: '/', icon: LayoutDashboard },
  { key: 'projects', path: '/projects', icon: FolderKanban, label: 'Projects' },
  { key: 'installations', path: '/installations', icon: Wrench },
  { key: 'vehicles', path: '/vehicles', icon: Car },
  { key: 'defects', path: '/defects', icon: AlertTriangle },
];

export default function MobileNav() {
  const { t } = useI18n();
  const location = useLocation();

  return (
    <nav className="fixed bottom-0 start-0 end-0 z-40 md:hidden bg-card border-t border-border">
      <div className="flex items-center justify-around h-16">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = item.path === '/'
            ? location.pathname === '/'
            : location.pathname.startsWith(item.path);
          return (
            <Link
              key={item.key}
              to={item.path}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg transition-colors ${
                isActive ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-[10px] font-medium">{item.label || t(item.key)}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
