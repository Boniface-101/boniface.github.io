import { useState, useRef, useCallback } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import MobileNav from './MobileNav';
import TopBar from './TopBar';

const PULL_THRESHOLD = 70;

export default function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [pullY, setPullY] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const touchStartY = useRef(null);
  const mainRef = useRef(null);

  const onTouchStart = useCallback((e) => {
    if (mainRef.current?.scrollTop === 0) {
      touchStartY.current = e.touches[0].clientY;
    }
  }, []);

  const onTouchMove = useCallback((e) => {
    if (touchStartY.current === null) return;
    const delta = e.touches[0].clientY - touchStartY.current;
    if (delta > 0) setPullY(Math.min(delta, PULL_THRESHOLD + 20));
  }, []);

  const onTouchEnd = useCallback(() => {
    if (pullY >= PULL_THRESHOLD) {
      setRefreshing(true);
      setTimeout(() => {
        window.location.reload();
      }, 500);
    }
    setPullY(0);
    touchStartY.current = null;
  }, [pullY]);

  return (
    <div className="min-h-screen bg-background">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="md:ms-64 flex flex-col min-h-screen">
        <TopBar onMenuToggle={() => setSidebarOpen(true)} />
        <main
          ref={mainRef}
          className="flex-1 p-4 md:p-6 pb-24 md:pb-6 overflow-y-auto"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
        >
          {(pullY > 0 || refreshing) && (
            <div
              className="md:hidden flex justify-center items-center transition-all overflow-hidden"
              style={{ height: refreshing ? 40 : Math.min(pullY * 0.5, 40) }}
            >
              <div className={`w-6 h-6 border-2 border-muted border-t-primary rounded-full ${refreshing ? 'animate-spin' : ''}`}
                style={{ transform: refreshing ? '' : `rotate(${(pullY / PULL_THRESHOLD) * 360}deg)` }}
              />
            </div>
          )}
          <Outlet />
        </main>
      </div>
      <MobileNav />
    </div>
  );
}
