export default function Analytics() {
  const { t } = useI18n();
  const [installations, setInstallations] = useState([]);
  const [defects, setDefects] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      base44.entities.Installation.list(),
      base44.entities.Defect.list()
    ]).then(([i, d]) => {
      setInstallations(i);
      setDefects(d);
    }).finally(() => setLoading(false));
  }, []);

  const completed = installations.filter(i => i.status === 'completed');
  const avgTime = completed.length > 0
    ? Math.round(completed.reduce((s, i) => s + (i.duration_minutes || 0), 0) / completed.length)
    : 0;
  const openDefects = defects.filter(d => d.status === 'open' || d.status === 'in_progress').length;

  // Monthly grouped data
  const monthly = {};
  installations.forEach(i => {
    const month = (i.date_of_installation || i.created_date)?.slice(0, 7);
    if (month) {
      if (!monthly[month]) monthly[month] = { month, completed: 0, failed: 0, total: 0 };
      monthly[month].total++;
      if (i.status === 'completed') monthly[month].completed++;
      if (i.status === 'rejected') monthly[month].failed++;
    }
  });
  const monthlyData = Object.values(monthly).sort((a, b) => a.month.localeCompare(b.month)).slice(-6);

  // Status pie
  const statusDist = {};
  installations.forEach(i => { statusDist[i.status] = (statusDist[i.status] || 0) + 1; });
  const pieData = Object.entries(statusDist).map(([name, value]) => ({ name: t(name), value }));

  // Technician performance
  const techPerf = {};
  installations.forEach(i => {
    if (i.technician_name) {
      if (!techPerf[i.technician_name]) techPerf[i.technician_name] = { name: i.technician_name, total: 0, completed: 0 };
      techPerf[i.technician_name].total++;
      if (i.status === 'completed') techPerf[i.technician_name].completed++;
    }
  });
  const techData = Object.values(techPerf).sort((a, b) => b.completed - a.completed);

  if (loading) return (
    <div className="flex justify-center py-12">
      <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold font-heading">{t('analytics')}</h1>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={CheckCircle} label={t('completed')} value={completed.length} color="success" />
        <StatCard icon={Clock} label={t('avg_install_time')} value={`${avgTime}m`} color="primary" />
        <StatCard icon={AlertTriangle} label={t('outstanding_defects')} value={openDefects} color="destructive" />
        <StatCard icon={Wrench} label="Total Installations" value={installations.length} color="secondary" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="font-heading font-semibold mb-4">{t('monthly_stats')}</h3>
          {monthlyData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={monthlyData} margin={{ top: 0, right: 0, bottom: 0, left: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220,13%,89%)" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="completed" fill="hsl(152,60%,40%)" radius={[4,4,0,0]} name={t('completed')} />
                <Bar dataKey="failed" fill="hsl(0,84%,60%)" radius={[4,4,0,0]} name={t('failed')} />
              </BarChart>
            </ResponsiveContainer>
          ) : <p className="text-sm text-muted-foreground py-8 text-center">{t('no_data')}</p>}
        </div>

        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="font-heading font-semibold mb-4">Status Distribution</h3>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" outerRadius={90} dataKey="value" label={({ name, value }) => `${name}: ${value}`} labelLine={false}>
                  {pieData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-sm text-muted-foreground py-8 text-center">{t('no_data')}</p>}
        </div>
      </div>

      {techData.length > 0 && (
        <div className="bg-card rounded-xl border border-border p-5">
          <h3 className="font-heading font-semibold mb-4">{t('tech_performance')}</h3>
          <div className="space-y-3">
            {techData.map((tech, i) => (
              <div key={i} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                <span className="font-medium text-sm">{tech.name}</span>
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-muted-foreground">{tech.total} total</span>
                  <span className="text-emerald-600 font-medium">{tech.completed} completed</span>
                  <span className="font-semibold w-10 text-end">
                    {tech.total > 0 ? Math.round(tech.completed / tech.total * 100) : 0}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/lib/i18n';
import { Link } from 'react-router-dom';
import { Plus, Search, Wrench, FileDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/components/ui/use-toast';
