export default function VehicleGroups() {
  const { toast } = useToast();
  const [groups, setGroups] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [expanded, setExpanded] = useState(null);
  const [form, setForm] = useState({ name: '', description: '', project_site: '' });
  const [selectedVehicle, setSelectedVehicle] = useState('');
  const [search, setSearch] = useState('');

  const load = async () => {
    setLoading(true);
    const [g, v] = await Promise.all([base44.entities.VehicleGroup.list(), base44.entities.Vehicle.list()]);
    setGroups(g); setVehicles(v); setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const createGroup = async () => {
    if (!form.name) { toast({ title: 'Group name required', variant: 'destructive' }); return; }
    await base44.entities.VehicleGroup.create({ ...form, vehicle_ids: [] });
    toast({ title: 'Group created' });
    setForm({ name: '', description: '', project_site: '' }); setShowForm(false); load();
  };

  const addVehicle = async (groupId, vehicleId) => {
    if (!vehicleId) return;
    const group = groups.find(g => g.id === groupId);
    if (!group) return;
    const ids = [...new Set([...(group.vehicle_ids || []), vehicleId])];
    await base44.entities.VehicleGroup.update(groupId, { vehicle_ids: ids });
    setSelectedVehicle(''); load();
  };

  const removeVehicle = async (groupId, vehicleId) => {
    const group = groups.find(g => g.id === groupId);
    if (!group) return;
    await base44.entities.VehicleGroup.update(groupId, { vehicle_ids: (group.vehicle_ids || []).filter(id => id !== vehicleId) });
    load();
  };

  const deleteGroup = async (id) => {
    await base44.entities.VehicleGroup.delete(id);
    toast({ title: 'Group deleted' }); load();
  };

  const vehicleMap = {};
  vehicles.forEach(v => { vehicleMap[v.id] = v; });

  const filteredGroups = groups.filter(g => !search || g.name?.toLowerCase().includes(search.toLowerCase()) || g.project_site?.toLowerCase().includes(search.toLowerCase()));

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center gap-3">
          <Layers className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold font-heading">Vehicle Groups</h1>
        </div>
        <div className="flex gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search groups..." className="pl-9 w-44" />
          </div>
          <Button size="sm" onClick={() => setShowForm(true)} className="gap-1.5"><Plus className="w-4 h-4" />New Group</Button>
        </div>
      </div>

      {filteredGroups.length === 0 ? (
        <div className="text-center py-16">
          <Layers className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground">{search ? 'No groups match your search' : 'No vehicle groups yet'}</p>
          {!search && <Button className="mt-4 gap-1.5" onClick={() => setShowForm(true)}><Plus className="w-4 h-4" />Create First Group</Button>}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredGroups.map(group => {
            const groupVehicles = (group.vehicle_ids || []).map(id => vehicleMap[id]).filter(Boolean);
            const available = vehicles.filter(v => !(group.vehicle_ids || []).includes(v.id));
            const isExpanded = expanded === group.id;
            return (
              <div key={group.id} className="bg-card rounded-xl border border-border overflow-hidden">
                <div className="p-4 flex items-center justify-between cursor-pointer hover:bg-muted/30" onClick={() => setExpanded(isExpanded ? null : group.id)}>
                  <div>
                    <p className="font-semibold">{group.name}</p>
                    <p className="text-xs text-muted-foreground">{group.project_site || '—'}{group.description ? ` · ${group.description}` : ''}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{groupVehicles.length} vehicle{groupVehicles.length !== 1 ? 's' : ''}</Badge>
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={e => { e.stopPropagation(); deleteGroup(group.id); }}><Trash2 className="w-3.5 h-3.5" /></Button>
                    <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </div>
                </div>
                {isExpanded && (
                  <div className="border-t border-border p-4 space-y-3">
                    {available.length > 0 && (
                      <div className="flex gap-2">
                        <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                          <SelectTrigger className="flex-1"><SelectValue placeholder="Add a vehicle to this group..." /></SelectTrigger>
                          <SelectContent>{available.map(v => <SelectItem key={v.id} value={v.id}>{v.door_number} — {v.plate_number} ({v.make} {v.model})</SelectItem>)}</SelectContent>
                        </Select>
                        <Button size="sm" onClick={() => addVehicle(group.id, selectedVehicle)} disabled={!selectedVehicle}>Add</Button>
                      </div>
                    )}
                    {groupVehicles.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-3">No vehicles assigned to this group</p>
                    ) : (
                      <div className="space-y-2">
                        {groupVehicles.map(v => (
                          <div key={v.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                            <div>
                              <p className="font-medium text-sm">{v.door_number} — {v.plate_number}</p>
                              <p className="text-xs text-muted-foreground">{v.make} {v.model} {v.year || ''} · {v.project_site || '—'}</p>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className={v.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : v.status === 'in_progress' ? 'bg-amber-100 text-amber-700' : 'bg-muted text-muted-foreground'}>{v.status || 'pending'}</Badge>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => removeVehicle(group.id, v.id)}><X className="w-3.5 h-3.5" /></Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Create Vehicle Group</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div><Label>Group Name *</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="mt-1" placeholder="e.g. Site A Vehicles" /></div>
            <div><Label>Project Site</Label><Input value={form.project_site} onChange={e => setForm(f => ({ ...f, project_site: e.target.value }))} className="mt-1" placeholder="e.g. Riyadh North" /></div>
            <div><Label>Description</Label><Input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} className="mt-1" /></div>
            <div className="flex justify-end gap-2"><Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button><Button onClick={createGroup}>Create Group</Button></div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/lib/i18n';
import { Plus, Search, Upload, Download, Car, Edit2, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const fields = [
  { key: 'door_number', required: true },
  { key: 'plate_number', required: true },
  { key: 'make', label: 'vehicle_make', required: true },
  { key: 'model', label: 'vehicle_model', required: true },
  { key: 'year', label: 'vehicle_year' },
  { key: 'vin' },
  { key: 'department' },
  { key: 'location' },
  { key: 'project_site' },
  { key: 'gps_unit_type', label: 'GPS Unit Type' },
  { key: 'unit_serial_number', label: 'Unit Serial Number' },
];
