export default function NewInstallation() {
  const { t, isRTL } = useI18n();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [step, setStep] = useState(0);
  const [vehicles, setVehicles] = useState([]);
  const [projects, setProjects] = useState([]);
  const [reps, setReps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [vehicleOpen, setVehicleOpen] = useState(false);
  const [viewPhoto, setViewPhoto] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  const [form, setForm] = useState({
    vehicle_id: '', project_id: '', date_of_installation: new Date().toISOString().slice(0, 10),
    start_time: new Date().toISOString(), checklist_items: [],
    test_results: DEFAULT_TESTS.map(name => ({ name, result: '', remarks: '' })),
    photos: [], technician_name: '', technician_employee_id: '',
    technician_company: 'Arabitra', technician_phone: '', technician_signature: '',
    technician_sign_date: '', client_name: '', client_employee_number: '',
    client_department: '', client_signature: '', client_sign_date: '',
    client_approval: 'pending', notes: '',
  });

  useEffect(() => {
    Promise.all([
      base44.entities.Vehicle.list(),
      base44.entities.ChecklistTemplate.filter({ is_active: true }),
      base44.entities.Representative.list(),
      base44.auth.me().catch(() => null),
      base44.entities.Project.list()
    ]).then(([v, c, r, me, p]) => {
      setVehicles(v);
      setReps(r);
      setProjects(p);
      setCurrentUser(me);
      const items = c.sort((a, b) => (a.order || 0) - (b.order || 0)).map(ci => ({
        name: ci.name, installed: '', serial_number: '', comments: '', photos: [],
      }));
      const draft = localStorage.getItem('ivms_draft');
      if (draft) {
        try {
          const { form: sf, step: ss } = JSON.parse(draft);
          if (sf?.vehicle_id) { setForm(sf); setStep(ss || 0); toast({ title: 'Draft restored' }); return; }
        } catch {}
      }
      setForm(f => ({ ...f, checklist_items: items }));
    }).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (form.vehicle_id) localStorage.setItem('ivms_draft', JSON.stringify({ form, step }));
  }, [form, step]);

  const updateChecklist = (idx, field, val) => {
    setForm(f => { const items = [...f.checklist_items]; items[idx] = { ...items[idx], [field]: val }; return { ...f, checklist_items: items }; });
  };
  const updateTest = (idx, field, val) => {
    setForm(f => { const tests = [...f.test_results]; tests[idx] = { ...tests[idx], [field]: val }; return { ...f, test_results: tests }; });
  };

  const handlePhotoUpload = async (e, checklistIdx) => {
    const files = Array.from(e.target.files);
    for (const file of files) {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      if (checklistIdx !== undefined) {
        setForm(f => { const items = [...f.checklist_items]; items[checklistIdx] = { ...items[checklistIdx], photos: [...(items[checklistIdx].photos || []), { url: file_url, timestamp: new Date().toISOString() }] }; return { ...f, checklist_items: items }; });
      } else {
        setForm(f => ({ ...f, photos: [...f.photos, { url: file_url, timestamp: new Date().toISOString(), description: '' }] }));
      }
    }
  };

  const selectRep = (repId, type) => {
    const rep = reps.find(r => r.id === repId);
    if (!rep) return;
    if (type === 'arabitra') {
      setForm(f => ({ ...f, technician_name: rep.name, technician_employee_id: rep.employee_id || '', technician_company: 'Arabitra', technician_phone: rep.phone || '', technician_signature: rep.signature_image || '', technician_sign_date: rep.signature_image ? new Date().toISOString() : '' }));
    } else {
      setForm(f => ({ ...f, client_name: rep.name, client_employee_number: rep.employee_id || '', client_department: rep.department || '', client_signature: rep.signature_image || '', client_sign_date: rep.signature_image ? new Date().toISOString() : '' }));
    }
  };

  const saveDraft = async () => {
    if (!form.vehicle_id) { toast({ title: 'Please select a vehicle', variant: 'destructive' }); setStep(0); return; }
    setSaving(true);
    const reportNum = `IVMS-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${Math.floor(1000 + Math.random() * 9000)}`;
    await base44.entities.Installation.create({ ...form, report_number: reportNum, status: 'draft' });
    localStorage.removeItem('ivms_draft');
    toast({ title: t('save_draft') + ' ✓' });
    navigate('/installations');
    setSaving(false);
  };

  const save = async () => {
    if (!form.vehicle_id) { toast({ title: 'Please select a vehicle', variant: 'destructive' }); setStep(0); return; }
    setSaving(true);
    const endTime = new Date().toISOString();
    const duration = Math.round((new Date(endTime) - new Date(form.start_time)) / 60000);
    const reportNum = `IVMS-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${Math.floor(1000 + Math.random() * 9000)}`;
    const existing = await base44.entities.Installation.filter({ vehicle_id: form.vehicle_id });
    const active = existing.filter(i => !['completed', 'rejected', 'fully_signed'].includes(i.status));
    if (active.length > 0 && currentUser?.role !== 'admin') {
      toast({ title: 'Active installation already exists for this vehicle', description: `Report: ${active[0].report_number || 'Draft'}. Contact admin to override.`, variant: 'destructive' });
      setSaving(false);
      return;
    }
    const completedChecklist = form.checklist_items.filter(i => i.installed !== '').length;
    const completedTests = form.test_results.filter(tr => tr.result !== '').length;
    const hasContent = completedChecklist > 0 || completedTests > 0;
    const hasTechSig = !!form.technician_signature;
    const hasClientSig = !!form.client_signature;
    let status;
    if (hasTechSig && hasClientSig) {
      status = form.client_approval === 'rejected' ? 'rejected' : 'fully_signed';
    } else if (hasTechSig || hasClientSig) {
      status = 'partially_signed';
    } else if (hasContent) {
      status = 'pending_signature';
    } else {
      status = 'in_progress';
    }
    const data = { ...form, end_time: endTime, duration_minutes: duration, report_number: reportNum, status };
    const inst = await base44.entities.Installation.create(data);
    const failedTests = form.test_results.filter(tr => tr.result === 'fail');
    for (const ft of failedTests) {
      await base44.entities.Defect.create({ installation_id: inst.id, vehicle_id: form.vehicle_id, issue: `${ft.name} - FAILED`, severity: 'high', responsible_party: form.technician_company || 'Arabitra', status: 'open', notes: ft.remarks || '' });
    }
    const isFullySigned = (hasTechSig && hasClientSig && form.client_approval !== 'rejected');
    await base44.entities.Vehicle.update(form.vehicle_id, { status: isFullySigned ? 'completed' : 'in_progress' });
    localStorage.removeItem('ivms_draft');
    toast({ title: t('report_generated') });
    navigate(`/installations/${inst.id}`);
    setSaving(false);
  };

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

  const BackIcon = isRTL ? ArrowRight : ArrowLeft;
  const NextIcon = isRTL ? ArrowLeft : ArrowRight;

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => step > 0 ? setStep(step - 1) : navigate('/installations')}><BackIcon className="w-5 h-5" /></Button>
        <div>
          <h1 className="text-xl font-bold font-heading">{t('new_installation')}</h1>
          <p className="text-sm text-muted-foreground">{t('step')} {step + 1} {t('of')} {STEPS.length}</p>
        </div>
      </div>

      <div className="flex gap-1">
        {STEPS.map((_, i) => (<div key={i} className={`h-1.5 flex-1 rounded-full transition-colors ${i <= step ? 'bg-primary' : 'bg-muted'}`} />))}
      </div>

      <div className="bg-card rounded-xl border border-border p-5">
        {step === 0 && (
          <div className="space-y-4">
            <h2 className="font-heading font-semibold text-lg">{t('vehicle_info')}</h2>
            <div>
              <Label>{t('select_vehicle')} *</Label>
              <Popover open={vehicleOpen} onOpenChange={setVehicleOpen}>
                <PopoverTrigger asChild>
                  <Button variant="outline" role="combobox" aria-expanded={vehicleOpen} className="w-full justify-between mt-1 font-normal">
                    {form.vehicle_id ? (() => { const v = vehicles.find(vh => vh.id === form.vehicle_id); return v ? `${v.door_number} — ${v.plate_number} (${v.make} ${v.model})` : t('select_vehicle'); })() : t('select_vehicle')}
                    <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="p-0" style={{ width: 'var(--radix-popover-trigger-width)' }} align="start">
                  <Command>
                    <CommandInput placeholder={t('search_placeholder')} />
                    <CommandList>
                      <CommandEmpty>{t('no_vehicles')}</CommandEmpty>
                      <CommandGroup>
                        {vehicles.map(v => (
                          <CommandItem key={v.id} value={`${v.door_number} ${v.plate_number} ${v.make} ${v.model}`} onSelect={() => { setForm(f => ({ ...f, vehicle_id: v.id, project_id: v.project_id || f.project_id })); setVehicleOpen(false); }}>
                            <Check className={cn("mr-2 h-4 w-4", form.vehicle_id === v.id ? "opacity-100" : "opacity-0")} />
                            {v.door_number} — {v.plate_number} ({v.make} {v.model})
                          </CommandItem>
                        ))}
                      </CommandGroup>
                    </CommandList>
                  </Command>
                </PopoverContent>
              </Popover>
            </div>
            {form.vehicle_id && projects.length > 0 && (
              <div>
                <Label>Project</Label>
                <Select value={form.project_id || ''} onValueChange={v => setForm(f => ({ ...f, project_id: v === 'none' ? '' : v }))}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select project..." /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">— No Project —</SelectItem>
                    {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
            <div>
              <Label>{t('date_of_installation')}</Label>
              <Input type="date" value={form.date_of_installation} onChange={e => setForm(f => ({ ...f, date_of_installation: e.target.value }))} className="mt-1" />
            </div>
            {vehicles.length === 0 && (
              <p className="text-sm text-amber-600 bg-amber-50 p-3 rounded-lg">No vehicles found. <a href="/vehicles" className="underline font-medium">Add vehicles first</a>.</p>
            )}
          </div>
        )}

        {step === 1 && (
          <div className="space-y-4">
            <h2 className="font-heading font-semibold text-lg">{t('checklist')}</h2>
            {form.checklist_items.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-6">No checklist items. <a href="/checklist-management" className="text-primary underline">Set up checklist</a> first.</p>
            ) : (
              <div className="space-y-4">
                {form.checklist_items.map((item, idx) => (
                  <div key={idx} className="border border-border rounded-lg p-4 space-y-3">
                    <p className="font-medium">{item.name}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <Label className="text-xs text-muted-foreground">{t('installed')}</Label>
                        <div className="flex gap-2 mt-1">
                          <Button type="button" size="sm" variant={item.installed === 'yes' ? 'default' : 'outline'} className={item.installed === 'yes' ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : ''} onClick={() => updateChecklist(idx, 'installed', item.installed === 'yes' ? '' : 'yes')}>{t('yes')}</Button>
                          <Button type="button" size="sm" variant={item.installed === 'no' ? 'destructive' : 'outline'} onClick={() => updateChecklist(idx, 'installed', item.installed === 'no' ? '' : 'no')}>{t('no')}</Button>
                          <Button type="button" size="sm" variant={item.installed === 'na' ? 'secondary' : 'outline'} onClick={() => updateChecklist(idx, 'installed', item.installed === 'na' ? '' : 'na')}>{t('not_applicable')}</Button>
                        </div>
                      </div>
                      <div><Label className="text-xs text-muted-foreground">{t('serial_number')}</Label><Input value={item.serial_number} onChange={e => updateChecklist(idx, 'serial_number', e.target.value)} className="mt-1" /></div>
                      <div><Label className="text-xs text-muted-foreground">{t('comments')}</Label><Input value={item.comments} onChange={e => updateChecklist(idx, 'comments', e.target.value)} className="mt-1" /></div>
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground flex items-center gap-1 cursor-pointer"><Camera className="w-3.5 h-3.5" />{t('photo_upload')}</Label>
                      <Input type="file" accept="image/*" multiple onChange={e => handlePhotoUpload(e, idx)} className="mt-1" />
                      {item.photos?.length > 0 && (
                        <div className="flex gap-2 mt-2 flex-wrap">
                          {item.photos.map((p, pi) => <img key={pi} src={p.url} className="w-16 h-16 rounded object-cover border cursor-pointer hover:opacity-80" alt="" onClick={() => setViewPhoto(p.url)} />)}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h2 className="font-heading font-semibold text-lg">{t('functional_testing')}</h2>
            {form.test_results.map((test, idx) => (
              <div key={idx} className="border border-border rounded-lg p-4">
                <p className="font-medium mb-3">{test.name}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="flex gap-2">
                    <Button type="button" size="sm" variant={test.result === 'pass' ? 'default' : 'outline'} className={test.result === 'pass' ? 'bg-emerald-600 hover:bg-emerald-700 text-white' : ''} onClick={() => updateTest(idx, 'result', test.result === 'pass' ? '' : 'pass')}>{t('pass')}</Button>
                    <Button type="button" size="sm" variant={test.result === 'fail' ? 'destructive' : 'outline'} onClick={() => updateTest(idx, 'result', test.result === 'fail' ? '' : 'fail')}>{t('fail')}</Button>
                  </div>
                  <Input placeholder={t('remarks')} value={test.remarks} onChange={e => updateTest(idx, 'remarks', e.target.value)} />
                </div>
              </div>
            ))}
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h2 className="font-heading font-semibold text-lg">{t('photos')}</h2>
            <div><Label>{t('photo_upload')}</Label><Input type="file" accept="image/*" multiple onChange={e => handlePhotoUpload(e)} className="mt-1" /></div>
            {form.photos.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {form.photos.map((p, i) => (
                  <div key={i}>
                    <img src={p.url} className="w-full h-24 rounded-lg object-cover border cursor-pointer hover:opacity-80" alt="" onClick={() => setViewPhoto(p.url)} />
                    <Input placeholder={t('description')} value={p.description} onChange={e => { setForm(f => { const photos = [...f.photos]; photos[i] = { ...photos[i], description: e.target.value }; return { ...f, photos }; }); }} className="mt-1 text-xs" />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <h2 className="font-heading font-semibold text-lg">{t('technician_declaration')}</h2>
            {reps.filter(r => r.company === 'Arabitra').length > 0 && (
              <div>
                <Label>Select {t('technician')}</Label>
                <Select onValueChange={v => selectRep(v, 'arabitra')}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select representative..." /></SelectTrigger>
                  <SelectContent>{reps.filter(r => r.company === 'Arabitra').map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><Label>{t('full_name')}</Label><Input value={form.technician_name} onChange={e => setForm(f => ({ ...f, technician_name: e.target.value }))} className="mt-1" /></div>
              <div><Label>{t('employee_id')}</Label><Input value={form.technician_employee_id} onChange={e => setForm(f => ({ ...f, technician_employee_id: e.target.value }))} className="mt-1" /></div>
              <div><Label>{t('company')}</Label><Input value={form.technician_company} onChange={e => setForm(f => ({ ...f, technician_company: e.target.value }))} className="mt-1" /></div>
              <div><Label>{t('phone')}</Label><Input value={form.technician_phone} onChange={e => setForm(f => ({ ...f, technician_phone: e.target.value }))} className="mt-1" /></div>
            </div>
            <div>
              <Label>{t('signature')}</Label>
              {form.technician_signature ? (
                <div className="mt-2">
                  <img src={form.technician_signature} className="h-20 border rounded bg-white" alt="Signature" />
                  <Button variant="ghost" size="sm" className="mt-1 text-xs text-destructive" onClick={() => setForm(f => ({ ...f, technician_signature: '', technician_sign_date: '' }))}><X className="w-3 h-3 mr-1" />Clear</Button>
                </div>
              ) : (
                <SignaturePad value="" onChange={sig => setForm(f => ({ ...f, technician_signature: sig, technician_sign_date: new Date().toISOString() }))} />
              )}
            </div>
          </div>
        )}

        {step === 5 && (
          <div className="space-y-4">
            <h2 className="font-heading font-semibold text-lg">{t('client_verification')}</h2>
            {reps.filter(r => r.company === 'Tamimi Global').length > 0 && (
              <div>
                <Label>Select {t('client')}</Label>
                <Select onValueChange={v => selectRep(v, 'tamimi')}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select representative..." /></SelectTrigger>
                  <SelectContent>{reps.filter(r => r.company === 'Tamimi Global').map(r => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div><Label>{t('name')}</Label><Input value={form.client_name} onChange={e => setForm(f => ({ ...f, client_name: e.target.value }))} className="mt-1" /></div>
              <div><Label>{t('employee_number')}</Label><Input value={form.client_employee_number} onChange={e => setForm(f => ({ ...f, client_employee_number: e.target.value }))} className="mt-1" /></div>
              <div><Label>{t('department')}</Label><Input value={form.client_department} onChange={e => setForm(f => ({ ...f, client_department: e.target.value }))} className="mt-1" /></div>
            </div>
            <div>
              <Label>{t('signature')}</Label>
              {form.client_signature ? (
                <div className="mt-2">
                  <img src={form.client_signature} className="h-20 border rounded bg-white" alt="Signature" />
                  <Button variant="ghost" size="sm" className="mt-1 text-xs text-destructive" onClick={() => setForm(f => ({ ...f, client_signature: '', client_sign_date: '' }))}><X className="w-3 h-3 mr-1" />Clear</Button>
                </div>
              ) : (
                <SignaturePad value="" onChange={sig => setForm(f => ({ ...f, client_signature: sig, client_sign_date: new Date().toISOString() }))} />
              )}
            </div>
            <div className="flex gap-3 pt-2">
              <Button type="button" onClick={() => setForm(f => ({ ...f, client_approval: 'approved' }))} className={`flex-1 gap-1.5 ${form.client_approval === 'approved' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-muted text-foreground hover:bg-muted/80'}`}><Check className="w-4 h-4" />{t('approve')}</Button>
              <Button type="button" variant="destructive" onClick={() => setForm(f => ({ ...f, client_approval: 'rejected' }))} className={`flex-1 ${form.client_approval === 'rejected' ? 'opacity-100' : 'opacity-50'}`}>{t('reject')}</Button>
            </div>
          </div>
        )}
      </div>

      <div className="flex justify-between">
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => step > 0 ? setStep(s => s - 1) : navigate('/installations')} className="gap-1.5"><BackIcon className="w-4 h-4" />{step > 0 ? t('previous') : t('back')}</Button>
          <Button variant="outline" onClick={saveDraft} disabled={saving} className="gap-1.5"><Save className="w-4 h-4" />{t('save_draft')}</Button>
        </div>
        {step < STEPS.length - 1 ? (
          <Button onClick={() => setStep(s => s + 1)} className="gap-1.5">{t('next')}<NextIcon className="w-4 h-4" /></Button>
        ) : (
          <Button onClick={save} disabled={saving} className="gap-1.5">{saving ? t('loading') : t('submit')}<Check className="w-4 h-4" /></Button>
        )}
      </div>

      {viewPhoto && (
        <Dialog open={!!viewPhoto} onOpenChange={() => setViewPhoto(null)}>
          <DialogContent className="max-w-3xl p-2">
            <img src={viewPhoto} className="w-full rounded" alt="" />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/lib/i18n';
import { Bell, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
