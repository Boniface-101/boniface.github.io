// TODO: Dashboard page - this file was not included in the exported code.
// Please recreate or add this page manually.
import { useI18n } from '@/lib/i18n';

export default function Dashboard() {
  const { t } = useI18n();
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <p className="text-muted-foreground mt-2">This page needs to be implemented.</p>
    </div>
  );
}
