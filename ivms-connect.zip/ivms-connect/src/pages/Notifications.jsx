export default function Notifications() {
  const { t } = useI18n();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    base44.entities.Notification.list('-created_date').then(setNotifications).finally(() => setLoading(false));
  };
  useEffect(() => { load(); }, []);

  const markRead = async (id) => {
    await base44.entities.Notification.update(id, { is_read: true });
    load();
  };

  const markAllRead = async () => {
    await Promise.all(notifications.filter(n => !n.is_read).map(n =>
      base44.entities.Notification.update(n.id, { is_read: true })
    ));
    load();
  };

  const typeEmoji = {
    installation_pending: '',
    signature_pending: '✍️',
    rejected: '❌',
    completed: '✅',
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold font-heading">{t('notifications')}</h1>
        {notifications.some(n => !n.is_read) && (
          <Button variant="outline" size="sm" onClick={markAllRead} className="gap-1.5">
            <Check className="w-4 h-4" />Mark all read
          </Button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>
      ) : notifications.length === 0 ? (
        <div className="text-center py-16">
          <Bell className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground">{t('no_data')}</p>
          <p className="text-sm text-muted-foreground mt-1">Notifications will appear here when actions are taken on installations.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map(n => (
            <div
              key={n.id}
              className={`bg-card rounded-xl border p-4 flex items-start gap-3 transition-colors ${
                !n.is_read ? 'border-primary/40 bg-accent/20' : 'border-border'
              }`}
            >
              <span className="text-xl flex-shrink-0">{typeEmoji[n.type] || '📢'}</span>
              <div className="flex-1 min-w-0">
                <p className={`text-sm ${!n.is_read ? 'font-semibold' : 'font-medium'}`}>{n.title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{n.message}</p>
                <p className="text-xs text-muted-foreground mt-1">{new Date(n.created_date).toLocaleString()}</p>
              </div>
              {!n.is_read && (
                <Button variant="ghost" size="icon" className="h-8 w-8 flex-shrink-0" onClick={() => markRead(n.id)}>
                  <Check className="w-4 h-4" />
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, MapPin, User, Phone, Car, Wrench, CheckCircle, Clock, AlertTriangle, FileText, ChevronRight, Edit } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

const statusConfig = {
  active: { label: 'Active', class: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  pending_handover: { label: 'Pending Handover', class: 'bg-amber-100 text-amber-700 border-amber-200' },
  completed: { label: 'Completed', class: 'bg-blue-100 text-blue-700 border-blue-200' },
};

const vStatusConfig = {
  pending: { label: 'Pending', class: 'bg-muted text-muted-foreground' },
  in_progress: { label: 'In Progress', class: 'bg-amber-100 text-amber-700' },
  completed: { label: 'Completed', class: 'bg-emerald-100 text-emerald-700' },
  failed: { label: 'Failed', class: 'bg-red-100 text-red-700' },
};
