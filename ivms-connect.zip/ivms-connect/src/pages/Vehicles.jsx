export default function Vehicles() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [vehicles, setVehicles] = useState([]);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [projectFilter, setProjectFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({});
  const fileRef = useRef();

  const load = () => {
    setLoading(true);
    Promise.all([
      base44.entities.Vehicle.list(),
      base44.entities.Project.list()
    ]).then(([v, p]) => { setVehicles(v); setProjects(p); }).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const projectMap = {};
  projects.forEach(p => { projectMap[p.id] = p; });

  const filtered = vehicles.filter(v => {
    const matchSearch = !search ||
      v.door_number?.toLowerCase().includes(search.toLowerCase()) ||
      v.plate_number?.toLowerCase().includes(search.toLowerCase()) ||
      v.vin?.toLowerCase().includes(search.toLowerCase());
    const matchProject = projectFilter === 'all' || v.project_id === projectFilter;
    return matchSearch && matchProject;
  });

  const openNew = () => { setEditing(null); setForm({}); setShowForm(true); };
  const openEdit = (v) => { setEditing(v); setForm({ ...v }); setShowForm(true); };

  const save = async () => {
    if (!form.door_number || !form.plate_number || !form.make || !form.model) {
      toast({ title: 'Please fill required fields', variant: 'destructive' });
      return;
    }
    if (editing) {
      await base44.entities.Vehicle.update(editing.id, form);
    } else {
      await base44.entities.Vehicle.create(form);
    }
    setShowForm(false);
    load();
  };

  const remove = async (id) => {
    await base44.entities.Vehicle.delete(id);
    load();
  };

  const downloadTemplate = () => {
    const headers = 'door_number,plate_number,make,model,year,vin,department,location,project_site';
    const sample = 'D001,ABC 1234,Toyota,Hilux,2023,1HGCM82633A004352,Operations,Riyadh,Site A';
    const blob = new Blob([headers + '\n' + sample], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'vehicle_import_template.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const handleBulkImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const text = await file.text();
    const lines = text.split('\n').filter(l => l.trim());
    if (lines.length < 2) { toast({ title: t('import_error'), variant: 'destructive' }); return; }
    const headers = lines[0].split(',').map(h => h.trim());
    const records = [];
    for (let i = 1; i < lines.length; i++) {
      const vals = lines[i].split(',').map(v => v.trim());
      const obj = {};
      headers.forEach((h, idx) => { if (vals[idx]) obj[h] = vals[idx]; });
      if (obj.door_number && obj.plate_number && obj.make && obj.model) records.push(obj);
    }
    if (records.length === 0) { toast({ title: t('import_error'), variant: 'destructive' }); return; }
    await base44.entities.Vehicle.bulkCreate(records);
    toast({ title: t('import_success'), description: `${records.length} vehicles imported` });
    load();
    e.target.value = '';
  };

  const statusColor = (s) => {
    const m = {
      pending: 'bg-muted text-muted-foreground',
      in_progress: 'bg-amber-100 text-amber-700',
      completed: 'bg-emerald-100 text-emerald-700',
      failed: 'bg-red-100 text-red-700'
    };
    return m[s] || m.pending;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold font-heading">{t('vehicles')}</h1>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" onClick={downloadTemplate} className="gap-1.5">
            <Download className="w-4 h-4" />{t('download_template')}
          </Button>
          <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} className="gap-1.5">
            <Upload className="w-4 h-4" />{t('bulk_import')}
          </Button>
          <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={handleBulkImport} />
          <Button size="sm" onClick={openNew} className="gap-1.5">
            <Plus className="w-4 h-4" />{t('new_vehicle')}
          </Button>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder={t('search_placeholder')} value={search} onChange={e => setSearch(e.target.value)} className="ps-9" />
        </div>
        <Select value={projectFilter} onValueChange={setProjectFilter}>
          <SelectTrigger className="w-full sm:w-52"><SelectValue placeholder="Filter by project" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Projects</SelectItem>
            {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Car className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground">{t('no_vehicles')}</p>
          <Button className="mt-4" onClick={openNew}><Plus className="w-4 h-4 me-2" />{t('add_vehicle')}</Button>
        </div>
      ) : (
        <>
          <div className="hidden md:block bg-card rounded-xl border border-border overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                    <th className="text-start p-3 font-medium text-muted-foreground">{t('door_number')}</th>
                    <th className="text-start p-3 font-medium text-muted-foreground">{t('plate_number')}</th>
                    <th className="text-start p-3 font-medium text-muted-foreground">{t('vehicle_make')}</th>
                    <th className="text-start p-3 font-medium text-muted-foreground">{t('vehicle_model')}</th>
                    <th className="text-start p-3 font-medium text-muted-foreground">Project</th>
                    <th className="text-start p-3 font-medium text-muted-foreground">{t('project_site')}</th>
                    <th className="text-start p-3 font-medium text-muted-foreground">{t('status')}</th>
                    <th className="text-start p-3 font-medium text-muted-foreground">{t('actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {filtered.map(v => (
                    <tr key={v.id} className="hover:bg-muted/30 transition-colors">
                      <td className="p-3 font-medium">{v.door_number}</td>
                      <td className="p-3">{v.plate_number}</td>
                      <td className="p-3">{v.make}</td>
                      <td className="p-3">{v.model} {v.year}</td>
                      <td className="p-3 text-muted-foreground text-xs">{v.project_id ? (projectMap[v.project_id]?.name || '—') : '—'}</td>
                      <td className="p-3 text-muted-foreground">{v.project_site || '—'}</td>
                      <td className="p-3"><Badge variant="outline" className={statusColor(v.status)}>{t(v.status)}</Badge></td>
                      <td className="p-3">
                        <div className="flex items-center gap-1">
                          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(v)}><Edit2 className="w-4 h-4" /></Button>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => remove(v.id)}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="md:hidden space-y-3">
            {filtered.map(v => (
              <div key={v.id} className="bg-card rounded-xl border border-border p-4">
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <p className="font-semibold">{v.door_number}</p>
                    <p className="text-sm text-muted-foreground">{v.plate_number}</p>
                  </div>
                  <Badge variant="outline" className={statusColor(v.status)}>{t(v.status)}</Badge>
                </div>
                <p className="text-sm">{v.make} {v.model} {v.year}</p>
                {v.project_site && <p className="text-xs text-muted-foreground mt-1">{v.project_site}</p>}
                <div className="flex gap-2 mt-3 pt-3 border-t border-border">
                  <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={() => openEdit(v)}><Edit2 className="w-3 h-3" />{t('edit')}</Button>
                  <Button variant="outline" size="sm" className="text-destructive gap-1" onClick={() => remove(v.id)}><Trash2 className="w-3 h-3" />{t('delete')}</Button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? t('edit_vehicle') : t('new_vehicle')}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
            <div className="sm:col-span-2">
              <Label className="text-sm">Project</Label>
              <Select value={form.project_id || ''} onValueChange={v => setForm({ ...form, project_id: v === 'none' ? '' : v })}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Assign to project..." /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— No Project —</SelectItem>
                  {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {fields.map(f => (
              <div key={f.key}>
                <Label className="text-sm">{f.label || t(f.label || f.key)}{f.required && ' *'}</Label>
                <Input
                  value={form[f.key] || ''}
                  onChange={e => setForm({ ...form, [f.key]: e.target.value })}
                  className="mt-1"
                />
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={() => setShowForm(false)}>{t('cancel')}</Button>
            <Button onClick={save}>{t('save')}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
