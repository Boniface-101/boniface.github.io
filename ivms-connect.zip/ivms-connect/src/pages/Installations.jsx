export default function Installations() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [installations, setInstallations] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState(new URLSearchParams(window.location.search).get('status') || 'all');
  const [selected, setSelected] = useState([]);

  useEffect(() => {
    Promise.all([
      base44.entities.Installation.list('-created_date'),
      base44.entities.Vehicle.list()
    ]).then(([i, v]) => {
      setInstallations(i);
      setVehicles(v);
    }).finally(() => setLoading(false));
  }, []);

  const vehicleMap = {};
  vehicles.forEach(v => { vehicleMap[v.id] = v; });

  const filtered = installations.filter(i => {
    const v = vehicleMap[i.vehicle_id];
    const matchSearch = !search ||
      i.report_number?.toLowerCase().includes(search.toLowerCase()) ||
      i.technician_name?.toLowerCase().includes(search.toLowerCase()) ||
      v?.door_number?.toLowerCase().includes(search.toLowerCase()) ||
      v?.plate_number?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || i.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const toggleSelect = (id) => {
    setSelected(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const toggleAll = () => {
    setSelected(selected.length === filtered.length ? [] : filtered.map(i => i.id));
  };

  // An installation is truly "done" only when both signatures are present
  const getDisplayStatus = (inst) => {
    if (inst.technician_signature && inst.client_signature && inst.client_approval !== 'rejected') {
      return { label: 'Done', class: 'bg-emerald-100 text-emerald-700' };
    }
    const map = {
      draft: { label: 'Draft', class: 'bg-muted text-muted-foreground' },
      in_progress: { label: 'In Progress', class: 'bg-amber-100 text-amber-700' },
      pending_signature: { label: 'Pending Signature', class: 'bg-blue-100 text-blue-700' },
      partially_signed: { label: 'Partially Signed', class: 'bg-indigo-100 text-indigo-700' },
      fully_signed: { label: 'Done', class: 'bg-emerald-100 text-emerald-700' },
      completed: { label: 'Done', class: 'bg-green-100 text-green-700' },
      rejected: { label: 'Rejected', class: 'bg-red-100 text-red-700' },
    };
    return map[inst.status] || { label: inst.status || 'Pending', class: 'bg-muted text-muted-foreground' };
  };

  const handleBulkPdf = () => {
    if (selected.length === 0) return;
    toast({ title: t('bulk_pdf'), description: `Generating ${selected.length} reports...` });
    selected.forEach(id => window.open(`/installations/${id}`, '_blank'));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <h1 className="text-2xl font-bold font-heading">{t('installations')}</h1>
        <div className="flex items-center gap-2">
          {selected.length > 0 && (
            <Button variant="outline" size="sm" onClick={handleBulkPdf} className="gap-1.5">
              <FileDown className="w-4 h-4" />{t('bulk_pdf')} ({selected.length})
            </Button>
          )}
          <Link to="/installations/new">
            <Button size="sm" className="gap-1.5"><Plus className="w-4 h-4" />{t('new_installation')}</Button>
          </Link>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder={t('search_placeholder')} value={search} onChange={e => setSearch(e.target.value)} className="ps-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t('all')}</SelectItem>
            <SelectItem value="draft">{t('draft')}</SelectItem>
            <SelectItem value="in_progress">{t('in_progress')}</SelectItem>
            <SelectItem value="pending_signature">{t('pending_signature')}</SelectItem>
            <SelectItem value="partially_signed">{t('partially_signed')}</SelectItem>
            <SelectItem value="fully_signed">{t('fully_signed')}</SelectItem>
            <SelectItem value="completed">{t('completed')}</SelectItem>
            <SelectItem value="rejected">{t('rejected')}</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Wrench className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground">{t('no_installations')}</p>
          <Link to="/installations/new"><Button className="mt-4 gap-1.5"><Plus className="w-4 h-4" />{t('new_installation')}</Button></Link>
        </div>
      ) : (
        <>
          <div className="hidden md:block bg-card rounded-xl border border-border overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/50">
                  <th className="p-3 w-10"><Checkbox checked={selected.length === filtered.length && filtered.length > 0} onCheckedChange={toggleAll} /></th>
                  <th className="text-start p-3 font-medium text-muted-foreground">{t('report_number')}</th>
                  <th className="text-start p-3 font-medium text-muted-foreground">{t('vehicles')}</th>
                  <th className="text-start p-3 font-medium text-muted-foreground">{t('technician_declaration')}</th>
                  <th className="text-start p-3 font-medium text-muted-foreground">{t('date')}</th>
                  <th className="text-start p-3 font-medium text-muted-foreground">{t('status')}</th>
                  <th className="text-start p-3 font-medium text-muted-foreground">{t('actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map(inst => {
                  const v = vehicleMap[inst.vehicle_id];
                  return (
                    <tr key={inst.id} className="hover:bg-muted/30 transition-colors">
                      <td className="p-3"><Checkbox checked={selected.includes(inst.id)} onCheckedChange={() => toggleSelect(inst.id)} /></td>
                      <td className="p-3 font-medium">{inst.report_number || `#${inst.id?.slice(-6)}`}</td>
                      <td className="p-3">{v ? `${v.door_number} — ${v.plate_number}` : '—'}</td>
                      <td className="p-3">{inst.technician_name || '—'}</td>
                      <td className="p-3 text-muted-foreground">{inst.date_of_installation || inst.created_date?.slice(0, 10)}</td>
                      <td className="p-3">{(() => { const ds = getDisplayStatus(inst); return <Badge variant="outline" className={ds.class}>{ds.label}</Badge>; })()}</td>
                      <td className="p-3">
                        <Link to={`/installations/${inst.id}`}>
                          <Button variant="ghost" size="sm">{t('view')}</Button>
                        </Link>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="md:hidden space-y-3">
            {filtered.map(inst => {
              const v = vehicleMap[inst.vehicle_id];
              return (
                <Link key={inst.id} to={`/installations/${inst.id}`} className="block">
                  <div className="bg-card rounded-xl border border-border p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={selected.includes(inst.id)}
                          onCheckedChange={() => toggleSelect(inst.id)}
                          onClick={e => e.stopPropagation()}
                        />
                        <p className="font-semibold">{inst.report_number || `#${inst.id?.slice(-6)}`}</p>
                      </div>
                      {(() => { const ds = getDisplayStatus(inst); return <Badge variant="outline" className={ds.class}>{ds.label}</Badge>; })()}
                    </div>
                    <p className="text-sm">{v ? `${v.door_number} — ${v.plate_number}` : '—'}</p>
                    <p className="text-xs text-muted-foreground mt-1">{inst.technician_name || '—'} · {inst.date_of_installation || inst.created_date?.slice(0, 10)}</p>
                  </div>
                </Link>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { LogIn, Mail, Lock, Loader2 } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
