export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [project, setProject] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [installations, setInstallations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editOpen, setEditOpen] = useState(false);
  const [editForm, setEditForm] = useState({});

  const load = async () => {
    setLoading(true);
    const [projects, allVehicles, allInstallations] = await Promise.all([
      base44.entities.Project.filter({ id }),
      base44.entities.Vehicle.list(),
      base44.entities.Installation.list()
    ]);
    const proj = projects[0];
    if (!proj) { setLoading(false); return; }
    setProject(proj);
    const projVehicles = allVehicles.filter(v => v.project_id === id);
    setVehicles(projVehicles);
    const vehicleIds = projVehicles.map(v => v.id);
    setInstallations(allInstallations.filter(i => vehicleIds.includes(i.vehicle_id)));
    setLoading(false);
  };

  useEffect(() => { if (id) load(); }, [id]);

  const getVehicleSignoffStatus = (vehicleId) => {
    const inst = installations.filter(i => i.vehicle_id === vehicleId).sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
    if (!inst) return { status: 'no_installation', arabitra: false, tamimi: false, inst: null };
    return {
      status: inst.technician_signature && inst.client_signature ? 'fully_signed' : inst.technician_signature || inst.client_signature ? 'partially_signed' : 'pending',
      arabitra: !!inst.technician_signature,
      tamimi: !!inst.client_signature,
      inst
    };
  };

  const signedOffCount = vehicles.filter(v => {
    const s = getVehicleSignoffStatus(v.id);
    return s.arabitra && s.tamimi;
  }).length;

  const canInitiateHandover = vehicles.length > 0;
  const allSignedOff = signedOffCount === vehicles.length && vehicles.length > 0;

  const saveEdit = async () => {
    await base44.entities.Project.update(project.id, editForm);
    toast({ title: 'Project updated' });
    setEditOpen(false);
    load();
  };

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;
  if (!project) return <div className="text-center py-16 text-muted-foreground">Project not found</div>;

  const sc = statusConfig[project.status] || statusConfig.active;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div className="flex items-start gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate('/projects')}><ArrowLeft className="w-5 h-5" /></Button>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold font-heading">{project.name}</h1>
              <Badge variant="outline" className={sc.class}>{sc.label}</Badge>
            </div>
            {project.location && <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="w-3.5 h-3.5" />{project.location}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2 ms-11 sm:ms-0">
          <Button variant="outline" size="sm" onClick={() => { setEditForm({ ...project }); setEditOpen(true); }} className="gap-1.5">
            <Edit className="w-4 h-4" />Edit
          </Button>
          <Link to={`/projects/${id}/handover`}>
            <Button size="sm" className="gap-1.5" variant={allSignedOff ? 'default' : 'outline'}>
              <FileText className="w-4 h-4" />
              {project.status === 'completed' ? 'View Handover' : 'Final Handover'}
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Vehicles', value: vehicles.length, icon: Car, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Fully Signed Off', value: signedOffCount, icon: CheckCircle, color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Pending Sign-off', value: vehicles.length - signedOffCount, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'Installations', value: installations.length, icon: Wrench, color: 'text-purple-600', bg: 'bg-purple-50' },
        ].map((stat, i) => (
          <div key={i} className="bg-card border border-border rounded-xl p-4">
            <div className={`w-9 h-9 rounded-lg ${stat.bg} flex items-center justify-center mb-3`}>
              <stat.icon className={`w-4.5 h-4.5 ${stat.color}`} style={{ width: '18px', height: '18px' }} />
            </div>
            <p className="text-2xl font-bold font-heading">{stat.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Project Info */}
      <div className="bg-card border border-border rounded-xl p-5">
        <h3 className="font-heading font-semibold mb-4">Project Details</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
          <div><p className="text-muted-foreground text-xs">Client</p><p className="font-medium">{project.client || 'Tamimi'}</p></div>
          <div><p className="text-muted-foreground text-xs">Contractor</p><p className="font-medium">{project.contractor || 'Arabitra'}</p></div>
          <div><p className="text-muted-foreground text-xs">Project Manager</p><p className="font-medium">{project.project_manager_name || '—'}</p></div>
          <div><p className="text-muted-foreground text-xs">PM Contact</p><p className="font-medium">{project.project_manager_contact || '—'}</p></div>
          <div><p className="text-muted-foreground text-xs">Start Date</p><p className="font-medium">{project.start_date || '—'}</p></div>
          <div><p className="text-muted-foreground text-xs">Expected End</p><p className="font-medium">{project.expected_end_date || '—'}</p></div>
        </div>
        {project.description && <p className="text-sm text-muted-foreground mt-4 pt-4 border-t border-border">{project.description}</p>}
      </div>

      {/* Handover Banner */}
      {!allSignedOff && vehicles.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-semibold text-amber-800 text-sm">Handover Not Ready</p>
            <p className="text-amber-700 text-xs mt-1">{vehicles.length - signedOffCount} vehicle(s) still pending both Arabitra + Tamimi signatures. You can still initiate handover with a warning.</p>
          </div>
        </div>
      )}

      {/* Vehicles Table */}
      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <h3 className="font-heading font-semibold">Vehicles in Project</h3>
          <Link to="/vehicles">
            <Button size="sm" variant="outline" className="gap-1.5 text-xs"><Car className="w-3.5 h-3.5" />Manage Vehicles</Button>
          </Link>
        </div>
        {vehicles.length === 0 ? (
          <div className="text-center py-12">
            <Car className="w-10 h-10 mx-auto text-muted-foreground/30 mb-2" />
            <p className="text-sm text-muted-foreground">No vehicles assigned to this project</p>
            <Link to="/vehicles"><Button size="sm" className="mt-3">Assign Vehicles</Button></Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Vehicle</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Make / Model</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">GPS Unit</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Serial No.</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Arabitra</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Tamimi</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Installation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {vehicles.map(v => {
                  const sig = getVehicleSignoffStatus(v.id);
                  return (
                    <tr key={v.id} className="hover:bg-muted/20 transition-colors">
                      <td className="p-3">
                        <p className="font-medium">{v.door_number}</p>
                        <p className="text-xs text-muted-foreground">{v.plate_number}</p>
                      </td>
                      <td className="p-3">{v.make} {v.model} {v.year}</td>
                      <td className="p-3 text-muted-foreground">{v.gps_unit_type || '—'}</td>
                      <td className="p-3 text-muted-foreground font-mono text-xs">{v.unit_serial_number || '—'}</td>
                      <td className="p-3">
                        {sig.arabitra ? <CheckCircle className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-muted-foreground/50" />}
                      </td>
                      <td className="p-3">
                        {sig.tamimi ? <CheckCircle className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-muted-foreground/50" />}
                      </td>
                      <td className="p-3">
                        {sig.inst ? (
                          <Link to={`/installations/${sig.inst.id}`}>
                            <Button variant="ghost" size="sm" className="gap-1 text-xs h-7">View<ChevronRight className="w-3 h-3" /></Button>
                          </Link>
                        ) : (
                          <Link to="/installations/new">
                            <Button variant="outline" size="sm" className="gap-1 text-xs h-7">Add</Button>
                          </Link>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Edit Project</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-2">
            <div><Label>Project Name *</Label><Input value={editForm.name || ''} onChange={e => setEditForm({ ...editForm, name: e.target.value })} className="mt-1" /></div>
            <div><Label>Location / Site</Label><Input value={editForm.location || ''} onChange={e => setEditForm({ ...editForm, location: e.target.value })} className="mt-1" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Client</Label><Input value={editForm.client || ''} onChange={e => setEditForm({ ...editForm, client: e.target.value })} className="mt-1" /></div>
              <div><Label>Contractor</Label><Input value={editForm.contractor || ''} onChange={e => setEditForm({ ...editForm, contractor: e.target.value })} className="mt-1" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Project Manager</Label><Input value={editForm.project_manager_name || ''} onChange={e => setEditForm({ ...editForm, project_manager_name: e.target.value })} className="mt-1" /></div>
              <div><Label>PM Contact</Label><Input value={editForm.project_manager_contact || ''} onChange={e => setEditForm({ ...editForm, project_manager_contact: e.target.value })} className="mt-1" /></div>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={editForm.status || 'active'} onValueChange={v => setEditForm({ ...editForm, status: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="pending_handover">Pending Handover</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={saveEdit}>Save</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowLeft, CheckCircle, Clock, AlertTriangle, Printer, Lock, FileText } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import SignaturePad from '@/components/installation/SignaturePad';

const TAMIMI_LOGO = 'https://media.base44.com/images/public/6a34fa46302f7a07b83d4032/bf75e8ac1_image.png';
const ARABITRA_LOGO = 'https://media.base44.com/images/public/6a34fa46302f7a07b83d4032/6c71482ff_image.png';
