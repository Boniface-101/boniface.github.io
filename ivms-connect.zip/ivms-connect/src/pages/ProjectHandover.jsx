export default function ProjectHandover() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const printRef = useRef();

  const [project, setProject] = useState(null);
  const [vehicles, setVehicles] = useState([]);
  const [installations, setInstallations] = useState([]);
  const [existingHandover, setExistingHandover] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  const [selectedVehicleIds, setSelectedVehicleIds] = useState([]);
  const [pmName, setPmName] = useState('');
  const [pmSignature, setPmSignature] = useState('');
  const [contractorName, setContractorName] = useState('');
  const [contractorSignature, setContractorSignature] = useState('');
  const [handoverDate, setHandoverDate] = useState(new Date().toISOString().slice(0, 10));

  const load = async () => {
    setLoading(true);
    const [projects, allVehicles, allInstallations, handovers] = await Promise.all([
      base44.entities.Project.filter({ id }),
      base44.entities.Vehicle.list(),
      base44.entities.Installation.list(),
      base44.entities.ProjectHandover.filter({ project_id: id })
    ]);
    const proj = projects[0];
    if (!proj) { setLoading(false); return; }
    setProject(proj);
    const projVehicles = allVehicles.filter(v => v.project_id === id);
    setVehicles(projVehicles);
    setInstallations(allInstallations.filter(i => projVehicles.map(v => v.id).includes(i.vehicle_id)));

    if (handovers.length > 0) {
      const h = handovers.sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0];
      setExistingHandover(h);
      setSelectedVehicleIds(h.vehicle_ids || []);
      setPmName(h.pm_name || proj.project_manager_name || '');
      setPmSignature(h.pm_signature || '');
      setContractorName(h.contractor_rep_name || '');
      setContractorSignature(h.contractor_signature || '');
      setHandoverDate(h.handover_date || new Date().toISOString().slice(0, 10));
    } else {
      setPmName(proj.project_manager_name || '');
      const completedVehicleIds = projVehicles.filter(v => {
        const inst = allInstallations.find(i => i.vehicle_id === v.id && i.technician_signature && i.client_signature);
        return !!inst;
      }).map(v => v.id);
      setSelectedVehicleIds(completedVehicleIds);
    }
    setLoading(false);
  };

  useEffect(() => { if (id) load(); }, [id]);

  const getVehicleInstallation = (vehicleId) => {
    return installations.filter(i => i.vehicle_id === vehicleId).sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0] || null;
  };

  const isFullySigned = (vehicleId) => {
    const inst = getVehicleInstallation(vehicleId);
    return inst && inst.technician_signature && inst.client_signature;
  };

  const signedCount = vehicles.filter(v => isFullySigned(v.id)).length;
  const pendingCount = vehicles.length - signedCount;
  const isFinalized = existingHandover?.status === 'finalized';

  const toggleVehicle = (vid) => {
    if (isFinalized) return;
    setSelectedVehicleIds(prev => prev.includes(vid) ? prev.filter(x => x !== vid) : [...prev, vid]);
  };

  const declarationText = `I, ${pmName || '[Project Manager Name]'}, confirm that I have received and accepted the above listed vehicles installed with GPS/IVMS units at ${project?.location || '[Location]'} on behalf of ${project?.client || 'Tamimi'}.`;

  const submit = async () => {
    if (!pmSignature) { toast({ title: 'Project Manager signature is required', variant: 'destructive' }); return; }
    if (!contractorSignature) { toast({ title: 'Contractor (Arabitra) signature is required', variant: 'destructive' }); return; }
    if (selectedVehicleIds.length === 0) { toast({ title: 'Select at least one vehicle', variant: 'destructive' }); return; }
    setSubmitting(true);
    const data = {
      project_id: id, handover_date: handoverDate,
      vehicle_ids: selectedVehicleIds, pm_name: pmName,
      pm_signature: pmSignature, pm_sign_date: new Date().toISOString(),
      contractor_rep_name: contractorName, contractor_signature: contractorSignature,
      contractor_sign_date: new Date().toISOString(),
      declaration_text: declarationText, status: 'finalized',
      finalized_at: new Date().toISOString(),
    };
    if (existingHandover) {
      await base44.entities.ProjectHandover.update(existingHandover.id, data);
    } else {
      await base44.entities.ProjectHandover.create(data);
    }
    await base44.entities.Project.update(id, { status: 'completed' });
    toast({ title: 'Handover finalized successfully', description: 'Project status set to Completed.' });
    load();
    setSubmitting(false);
  };

  const handlePrint = () => window.print();

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;
  if (!project) return <div className="text-center py-16 text-muted-foreground">Project not found</div>;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 print:hidden">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => navigate(`/projects/${id}`)}><ArrowLeft className="w-5 h-5" /></Button>
          <div>
            <h1 className="text-xl font-bold font-heading">Final Project Handover</h1>
            <p className="text-sm text-muted-foreground">{project.name}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isFinalized && <Badge variant="outline" className="bg-emerald-100 text-emerald-700 border-emerald-200 gap-1.5"><Lock className="w-3 h-3" />Finalized</Badge>}
          <Button variant="outline" size="sm" onClick={handlePrint} className="gap-1.5"><Printer className="w-4 h-4" />Print</Button>
        </div>
      </div>

      {/* Pending Warning */}
      {pendingCount > 0 && !isFinalized && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 flex items-start gap-3 print:hidden">
          <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-semibold text-amber-800 text-sm">Warning: {pendingCount} vehicle(s) not fully signed off</p>
            <p className="text-amber-700 text-xs mt-1">You can still proceed, but only signed-off vehicles will be pre-selected. You can manually include unsigned vehicles.</p>
          </div>
        </div>
      )}

      {/* Printable Document */}
      <div ref={printRef} className="bg-card border border-border rounded-xl overflow-hidden print:border-0 print:rounded-none">
        {/* Document Header */}
        <div className="p-6 border-b border-border bg-muted/20 print:bg-white">
          <div className="flex items-center justify-between mb-4">
            <img src={TAMIMI_LOGO} alt="Tamimi" className="h-12 object-contain" />
            <div className="text-center">
              <h2 className="font-heading font-bold text-lg">GPS/IVMS Installation Handover Certificate</h2>
              <p className="text-xs text-muted-foreground mt-0.5">Project Final Handover Document</p>
            </div>
            <img src={ARABITRA_LOGO} alt="Arabitra" className="h-10 object-contain" />
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm mt-4">
            <div><p className="text-muted-foreground text-xs">Project Name</p><p className="font-semibold">{project.name}</p></div>
            <div><p className="text-muted-foreground text-xs">Location</p><p className="font-semibold">{project.location || '—'}</p></div>
            <div><p className="text-muted-foreground text-xs">Client</p><p className="font-semibold">{project.client || 'Tamimi'}</p></div>
            <div><p className="text-muted-foreground text-xs">Contractor</p><p className="font-semibold">{project.contractor || 'Arabitra'}</p></div>
          </div>
          <div className="mt-3">
            <Label className="text-xs text-muted-foreground">Date of Handover</Label>
            {isFinalized ? (
              <p className="font-semibold text-sm mt-0.5">{handoverDate}</p>
            ) : (
              <Input type="date" value={handoverDate} onChange={e => setHandoverDate(e.target.value)} className="mt-1 w-48" />
            )}
          </div>
        </div>

        {/* Vehicle Table */}
        <div className="p-6 border-b border-border">
          <h3 className="font-heading font-semibold mb-4 flex items-center gap-2">
            <FileText className="w-4 h-4 text-primary" />Vehicle Handover List
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  {!isFinalized && <th className="p-3 w-10 text-start"><Checkbox checked={selectedVehicleIds.length === vehicles.length && vehicles.length > 0} onCheckedChange={checked => setSelectedVehicleIds(checked ? vehicles.map(v => v.id) : [])} /></th>}
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Plate / Door No.</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Make & Model</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">GPS Unit Type</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Serial No.</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Install Date</th>
                  <th className="text-start p-3 font-medium text-muted-foreground text-xs">Sign-off Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {vehicles.filter(v => isFinalized ? selectedVehicleIds.includes(v.id) : true).map(v => {
                  const inst = getVehicleInstallation(v.id);
                  const signed = isFullySigned(v.id);
                  const selected = selectedVehicleIds.includes(v.id);
                  return (
                    <tr key={v.id} className={`transition-colors ${selected ? 'bg-primary/3' : ''} ${!selected && !isFinalized ? 'opacity-50' : ''}`}>
                      {!isFinalized && (
                        <td className="p-3">
                          <Checkbox checked={selected} onCheckedChange={() => toggleVehicle(v.id)} />
                        </td>
                      )}
                      <td className="p-3">
                        <p className="font-medium">{v.plate_number}</p>
                        <p className="text-xs text-muted-foreground">{v.door_number}</p>
                      </td>
                      <td className="p-3">{v.make} {v.model} {v.year}</td>
                      <td className="p-3 text-muted-foreground">{v.gps_unit_type || '—'}</td>
                      <td className="p-3 font-mono text-xs text-muted-foreground">{v.unit_serial_number || '—'}</td>
                      <td className="p-3 text-muted-foreground">{inst?.date_of_installation || '—'}</td>
                      <td className="p-3">
                        {signed ? (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                            <CheckCircle className="w-3 h-3" />Both Signed
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">
                            <Clock className="w-3 h-3" />Pending
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {!isFinalized && (
            <p className="text-xs text-muted-foreground mt-3">
              {selectedVehicleIds.length} of {vehicles.length} vehicles selected for handover
            </p>
          )}
        </div>

        {/* Declaration */}
        <div className="p-6 border-b border-border">
          <h3 className="font-heading font-semibold mb-4">Project Manager Declaration</h3>
          <div className="bg-muted/30 rounded-lg p-4 mb-4 border border-border">
            <p className="text-sm leading-relaxed italic text-foreground/80">{declarationText}</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* PM Signature */}
            <div className="space-y-3">
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Project Manager Name</Label>
                {isFinalized ? (
                  <p className="font-semibold mt-1">{pmName || '—'}</p>
                ) : (
                  <Input value={pmName} onChange={e => setPmName(e.target.value)} className="mt-1" placeholder="Full name..." />
                )}
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">PM Signature</Label>
                {pmSignature ? (
                  <div className="mt-1">
                    <img src={pmSignature} alt="PM Signature" className="h-20 border rounded bg-white object-contain w-full" />
                    {!isFinalized && <Button variant="ghost" size="sm" className="mt-1 text-xs text-destructive" onClick={() => setPmSignature('')}>Clear</Button>}
                  </div>
                ) : !isFinalized ? (
                  <SignaturePad value="" onChange={setPmSignature} />
                ) : <p className="text-muted-foreground text-sm mt-1">—</p>}
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Date</Label>
                <p className="text-sm font-medium mt-0.5">{handoverDate}</p>
              </div>
            </div>

            {/* Contractor Signature */}
            <div className="space-y-3">
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Arabitra Representative</Label>
                {isFinalized ? (
                  <p className="font-semibold mt-1">{contractorName || '—'}</p>
                ) : (
                  <Input value={contractorName} onChange={e => setContractorName(e.target.value)} className="mt-1" placeholder="Arabitra rep name..." />
                )}
              </div>
              <div>
                <Label className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Arabitra Signature</Label>
                {contractorSignature ? (
                  <div className="mt-1">
                    <img src={contractorSignature} alt="Contractor Signature" className="h-20 border rounded bg-white object-contain w-full" />
                    {!isFinalized && <Button variant="ghost" size="sm" className="mt-1 text-xs text-destructive" onClick={() => setContractorSignature('')}>Clear</Button>}
                  </div>
                ) : !isFinalized ? (
                  <SignaturePad value="" onChange={setContractorSignature} />
                ) : <p className="text-muted-foreground text-sm mt-1">—</p>}
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Date</Label>
                <p className="text-sm font-medium mt-0.5">{handoverDate}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-muted/20 text-xs text-muted-foreground flex justify-between items-center">
          <span>IVMS Connect — GPS Installation Handover Certificate</span>
          <span>Generated: {new Date().toLocaleDateString()}</span>
        </div>
      </div>

      {/* Submit Button */}
      {!isFinalized && (
        <div className="flex justify-end gap-3 print:hidden">
          <Button variant="outline" onClick={() => navigate(`/projects/${id}`)}>Cancel</Button>
          <Button onClick={submit} disabled={submitting} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white min-w-40">
            <Lock className="w-4 h-4" />
            {submitting ? 'Finalizing...' : 'Finalize Handover'}
          </Button>
        </div>
      )}

      {isFinalized && (
        <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-center gap-3 print:hidden">
          <CheckCircle className="w-5 h-5 text-emerald-600 flex-shrink-0" />
          <div>
            <p className="font-semibold text-emerald-800 text-sm">Handover Finalized</p>
            <p className="text-emerald-700 text-xs mt-0.5">This document is locked and cannot be edited. Use the Print button to export.</p>
          </div>
        </div>
      )}

      <style>{`
        @media print {
          .print\\:hidden { display: none !important; }
          .print\\:border-0 { border: 0 !important; }
          .print\\:rounded-none { border-radius: 0 !important; }
          .print\\:bg-white { background: white !important; }
          body { background: white; }
        }
      `}</style>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { BarChart3, Car, CheckCircle, Clock, FolderOpen, Printer, Search, Filter, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

const TAMIMI_LOGO = 'https://media.base44.com/images/public/6a34fa46302f7a07b83d4032/bf75e8ac1_image.png';
const ARABITRA_LOGO = 'https://media.base44.com/images/public/6a34fa46302f7a07b83d4032/6c71482ff_image.png';

const statusConfig = {
  active: { label: 'Active', class: 'bg-emerald-100 text-emerald-700' },
  pending_handover: { label: 'Pending Handover', class: 'bg-amber-100 text-amber-700' },
  completed: { label: 'Completed', class: 'bg-blue-100 text-blue-700' },
};
