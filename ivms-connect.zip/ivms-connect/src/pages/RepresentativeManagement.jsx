export default function RepresentativeManagement() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [reps, setReps] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', employee_id: '', company: 'Arabitra', department: '', phone: '', signature_image: '' });
  const [uploading, setUploading] = useState(false);

  const load = () => { setLoading(true); base44.entities.Representative.list().then(setReps).finally(() => setLoading(false)); };
  useEffect(() => { load(); }, []);

  const handleSigUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm(f => ({ ...f, signature_image: file_url }));
    setUploading(false);
  };

  const save = async () => {
    if (!form.name || !form.company) { toast({ title: 'Name and company required', variant: 'destructive' }); return; }
    await base44.entities.Representative.create(form);
    toast({ title: 'Representative added' });
    setForm({ name: '', employee_id: '', company: 'Arabitra', department: '', phone: '', signature_image: '' });
    setShowForm(false);
    load();
  };

  const remove = async (id) => { await base44.entities.Representative.delete(id); load(); };

  const arabitra = reps.filter(r => r.company === 'Arabitra');
  const tamimi = reps.filter(r => r.company === 'Tamimi Global');

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

  const RepList = ({ title, list }) => (
    <div className="bg-card rounded-xl border border-border overflow-hidden">
      <div className="p-4 border-b border-border"><h3 className="font-heading font-semibold">{title}</h3></div>
      {list.length === 0 ? (
        <p className="p-4 text-sm text-muted-foreground text-center">No representatives registered</p>
      ) : (
        <div className="divide-y divide-border">
          {list.map(r => (
            <div key={r.id} className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                {r.signature_image ? (
                  <img src={r.signature_image} className="w-12 h-8 border rounded bg-white object-contain" alt="" />
                ) : (
                  <div className="w-12 h-8 border rounded bg-muted flex items-center justify-center text-xs text-muted-foreground">N/A</div>
                )}
                <div>
                  <p className="font-medium text-sm">{r.name}</p>
                  <p className="text-xs text-muted-foreground">{r.employee_id || '—'} · {r.department || '—'} · {r.phone || '—'}</p>
                </div>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => remove(r.id)}><Trash2 className="w-4 h-4" /></Button>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <UserCheck className="w-6 h-6 text-primary" />
          <h1 className="text-2xl font-bold font-heading">{t('representatives')}</h1>
        </div>
        <Button size="sm" onClick={() => setShowForm(true)} className="gap-1.5"><Plus className="w-4 h-4" />Add</Button>
      </div>

      <RepList title="Arabitra Representatives" list={arabitra} />
      <RepList title="Tamimi Global Representatives" list={tamimi} />

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Add Representative</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-4">
            <div><Label>Name *</Label><Input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="mt-1" /></div>
            <div>
              <Label>Company *</Label>
              <Select value={form.company} onValueChange={v => setForm(f => ({ ...f, company: v }))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Arabitra">Arabitra</SelectItem>
                  <SelectItem value="Tamimi Global">Tamimi Global</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Employee ID</Label><Input value={form.employee_id} onChange={e => setForm(f => ({ ...f, employee_id: e.target.value }))} className="mt-1" /></div>
              <div><Label>Department</Label><Input value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))} className="mt-1" /></div>
            </div>
            <div><Label>Phone</Label><Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} className="mt-1" /></div>
            <div>
              <Label>Signature Image</Label>
              <Input type="file" accept="image/*" onChange={handleSigUpload} className="mt-1" />
              {uploading && <p className="text-xs text-muted-foreground mt-1">Uploading...</p>}
              {form.signature_image && <img src={form.signature_image} className="h-16 mt-2 border rounded bg-white" alt="Signature" />}
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowForm(false)}>{t('cancel')}</Button>
              <Button onClick={save}>{t('save')}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import React, { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Lock, Loader2, AlertTriangle } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
