export default function Projects() {
  const { toast } = useToast();
  const [projects, setProjects] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [installations, setInstallations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: '', location: '', client: 'Tamimi', contractor: 'Arabitra', project_manager_name: '', project_manager_contact: '', status: 'active', description: '', start_date: '', expected_end_date: '' });

  const load = async () => {
    setLoading(true);
    const [p, v, i] = await Promise.all([
      base44.entities.Project.list('-created_date'),
      base44.entities.Vehicle.list(),
      base44.entities.Installation.list()
    ]);
    setProjects(p);
    setVehicles(v);
    setInstallations(i);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = projects.filter(p => {
    const matchSearch = !search || p.name?.toLowerCase().includes(search.toLowerCase()) || p.location?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const getProjectStats = (projectId) => {
    const projectVehicles = vehicles.filter(v => v.project_id === projectId);
    const completedVehicles = projectVehicles.filter(v => {
      const inst = installations.find(i => i.vehicle_id === v.id && i.technician_signature && i.client_signature);
      return !!inst;
    });
    return { total: projectVehicles.length, completed: completedVehicles.length };
  };

  const openNew = () => {
    setEditing(null);
    setForm({ name: '', location: '', client: 'Tamimi', contractor: 'Arabitra', project_manager_name: '', project_manager_contact: '', status: 'active', description: '', start_date: '', expected_end_date: '' });
    setShowForm(true);
  };

  const openEdit = (p) => { setEditing(p); setForm({ ...p }); setShowForm(true); };

  const save = async () => {
    if (!form.name) { toast({ title: 'Project name is required', variant: 'destructive' }); return; }
    if (editing) {
      await base44.entities.Project.update(editing.id, form);
    } else {
      await base44.entities.Project.create(form);
    }
    setShowForm(false);
    load();
    toast({ title: editing ? 'Project updated' : 'Project created' });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-heading">Projects</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage vehicle installation projects</p>
        </div>
        <Button size="sm" onClick={openNew} className="gap-1.5 self-start sm:self-auto">
          <Plus className="w-4 h-4" />New Project
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Search projects..." value={search} onChange={e => setSearch(e.target.value)} className="ps-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="active">Active</SelectItem>
            <SelectItem value="pending_handover">Pending Handover</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <FolderOpen className="w-12 h-12 mx-auto text-muted-foreground/40 mb-3" />
          <p className="text-muted-foreground">No projects found</p>
          <Button className="mt-4" onClick={openNew}><Plus className="w-4 h-4 me-2" />Create Project</Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map(project => {
            const stats = getProjectStats(project.id);
            const pct = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
            const sc = statusConfig[project.status] || statusConfig.active;
            return (
              <div key={project.id} className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow group">
                <div className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <FolderOpen className="w-5 h-5 text-primary" />
                    </div>
                    <Badge variant="outline" className={sc.class}>{sc.label}</Badge>
                  </div>
                  <h3 className="font-heading font-semibold text-base mb-1 line-clamp-1">{project.name}</h3>
                  {project.location && (
                    <div className="flex items-center gap-1.5 text-sm text-muted-foreground mb-3">
                      <MapPin className="w-3.5 h-3.5 flex-shrink-0" />{project.location}
                    </div>
                  )}
                  <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                    <div className="flex items-center gap-1"><Building2 className="w-3.5 h-3.5" />{project.client || 'Tamimi'}</div>
                    {project.project_manager_name && <div className="flex items-center gap-1"><User className="w-3.5 h-3.5" />{project.project_manager_name}</div>}
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs">
                      <span className="text-muted-foreground">Vehicles signed off</span>
                      <span className="font-medium">{stats.completed}/{stats.total}</span>
                    </div>
                    <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-primary rounded-full transition-all" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                </div>
                <div className="px-5 pb-4 flex gap-2">
                  <Link to={`/projects/${project.id}`} className="flex-1">
                    <Button size="sm" variant="outline" className="w-full gap-1.5 group-hover:border-primary group-hover:text-primary transition-colors">
                      View Project<ChevronRight className="w-3.5 h-3.5" />
                    </Button>
                  </Link>
                  <Button size="sm" variant="ghost" onClick={() => openEdit(project)}>Edit</Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Project' : 'New Project'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <Label>Project Name *</Label>
              <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="mt-1" placeholder="e.g. Tamimi Distribution Center — Riyadh" />
            </div>
            <div>
              <Label>Location / Site</Label>
              <Input value={form.location} onChange={e => setForm({ ...form, location: e.target.value })} className="mt-1" placeholder="e.g. Riyadh Industrial Zone" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Client</Label>
                <Input value={form.client} onChange={e => setForm({ ...form, client: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>Contractor</Label>
                <Input value={form.contractor} onChange={e => setForm({ ...form, contractor: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Project Manager</Label>
                <Input value={form.project_manager_name} onChange={e => setForm({ ...form, project_manager_name: e.target.value })} className="mt-1" placeholder="Full name" />
              </div>
              <div>
                <Label>PM Contact</Label>
                <Input value={form.project_manager_contact} onChange={e => setForm({ ...form, project_manager_contact: e.target.value })} className="mt-1" placeholder="+966..." />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Start Date</Label>
                <Input type="date" value={form.start_date} onChange={e => setForm({ ...form, start_date: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>Expected End Date</Label>
                <Input type="date" value={form.expected_end_date} onChange={e => setForm({ ...form, expected_end_date: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div>
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm({ ...form, status: v })}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="pending_handover">Pending Handover</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Description</Label>
              <Input value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="mt-1" placeholder="Optional notes..." />
            </div>
          </div>
          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={save}>Save Project</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserPlus, Mail, Lock, Loader2 } from "lucide-react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import { toast } from "@/components/ui/use-toast";
