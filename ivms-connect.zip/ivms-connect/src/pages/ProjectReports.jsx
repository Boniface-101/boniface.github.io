export default function ProjectReports() {
  const [projects, setProjects] = useState([]);
  const [vehicles, setVehicles] = useState([]);
  const [installations, setInstallations] = useState([]);
  const [handovers, setHandovers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [reportTab, setReportTab] = useState('summary');

  useEffect(() => {
    Promise.all([
      base44.entities.Project.list('-created_date'),
      base44.entities.Vehicle.list(),
      base44.entities.Installation.list('-created_date'),
      base44.entities.ProjectHandover.list()
    ]).then(([p, v, i, h]) => {
      setProjects(p);
      setVehicles(v);
      setInstallations(i);
      setHandovers(h);
    }).finally(() => setLoading(false));
  }, []);

  const getProjectVehicles = (projectId) => vehicles.filter(v => v.project_id === projectId);

  const getVehicleInstallation = (vehicleId) => {
    return installations.filter(i => i.vehicle_id === vehicleId).sort((a, b) => new Date(b.created_date) - new Date(a.created_date))[0] || null;
  };

  const isFullySigned = (vehicleId) => {
    const inst = getVehicleInstallation(vehicleId);
    return inst && inst.technician_signature && inst.client_signature;
  };

  const getProjectStats = (projectId) => {
    const pv = getProjectVehicles(projectId);
    const completed = pv.filter(v => isFullySigned(v.id)).length;
    const inProgress = pv.filter(v => {
      const inst = getVehicleInstallation(v.id);
      return inst && (!inst.technician_signature || !inst.client_signature);
    }).length;
    return { total: pv.length, completed, inProgress, pending: pv.length - completed - inProgress };
  };

  const filteredProjects = projects.filter(p => {
    if (selectedProject !== 'all' && p.id !== selectedProject) return false;
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (dateFrom && p.start_date && p.start_date < dateFrom) return false;
    if (dateTo && p.start_date && p.start_date > dateTo) return false;
    return true;
  });

  const handlePrint = () => window.print();

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

  const tabs = [
    { key: 'summary', label: 'Project Summary' },
    { key: 'fleet', label: 'Fleet Count' },
    { key: 'certificate', label: 'Handover Certificates' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 print:hidden">
        <div>
          <h1 className="text-2xl font-bold font-heading">Project Reports</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Summary, fleet counts, and handover certificates</p>
        </div>
        <Button variant="outline" size="sm" onClick={handlePrint} className="gap-1.5 self-start"><Printer className="w-4 h-4" />Print Report</Button>
      </div>

      {/* Filters */}
      <div className="bg-card border border-border rounded-xl p-4 print:hidden">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium">Filters</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <Label className="text-xs">Project</Label>
            <Select value={selectedProject} onValueChange={setSelectedProject}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Status</Label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending_handover">Pending Handover</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Date From</Label>
            <Input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="mt-1" />
          </div>
          <div>
            <Label className="text-xs">Date To</Label>
            <Input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="mt-1" />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted/50 p-1 rounded-lg w-fit print:hidden">
        {tabs.map(tab => (
          <button key={tab.key} onClick={() => setReportTab(tab.key)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${reportTab === tab.key ? 'bg-card shadow-sm text-foreground' : 'text-muted-foreground hover:text-foreground'}`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* Project Summary Tab */}
      {reportTab === 'summary' && (
        <div className="space-y-4">
          {filteredProjects.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">No projects match your filters</div>
          ) : filteredProjects.map(project => {
            const stats = getProjectStats(project.id);
            const pv = getProjectVehicles(project.id);
            const sc = statusConfig[project.status] || statusConfig.active;
            return (
              <div key={project.id} className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="px-5 py-4 border-b border-border flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FolderOpen className="w-5 h-5 text-primary" />
                    <div>
                      <h3 className="font-heading font-semibold">{project.name}</h3>
                      <p className="text-xs text-muted-foreground">{project.location || 'No location'} · {project.client || 'Tamimi'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className={sc.class}>{sc.label}</Badge>
                    <Link to={`/projects/${project.id}`}><Button size="sm" variant="ghost" className="text-xs">View</Button></Link>
                  </div>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">Vehicle</th>
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">Make & Model</th>
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">GPS Unit</th>
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">Serial No.</th>
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">Install Date</th>
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">Arabitra</th>
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">Tamimi</th>
                        <th className="text-start p-3 font-medium text-muted-foreground text-xs">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {pv.map(v => {
                        const inst = getVehicleInstallation(v.id);
                        const arSigned = inst && !!inst.technician_signature;
                        const tamSigned = inst && !!inst.client_signature;
                        return (
                          <tr key={v.id} className="hover:bg-muted/20">
                            <td className="p-3">
                              <p className="font-medium">{v.door_number}</p>
                              <p className="text-xs text-muted-foreground">{v.plate_number}</p>
                            </td>
                            <td className="p-3">{v.make} {v.model} {v.year}</td>
                            <td className="p-3 text-muted-foreground">{v.gps_unit_type || '—'}</td>
                            <td className="p-3 font-mono text-xs text-muted-foreground">{v.unit_serial_number || '—'}</td>
                            <td className="p-3 text-muted-foreground">{inst?.date_of_installation || '—'}</td>
                            <td className="p-3">{arSigned ? <CheckCircle className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-muted-foreground/40" />}</td>
                            <td className="p-3">{tamSigned ? <CheckCircle className="w-4 h-4 text-emerald-600" /> : <Clock className="w-4 h-4 text-muted-foreground/40" />}</td>
                            <td className="p-3">
                              {arSigned && tamSigned ? (
                                <span className="text-xs text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">Signed Off</span>
                              ) : inst ? (
                                <span className="text-xs text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">Partial</span>
                              ) : (
                                <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full">No Install</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                <div className="px-5 py-3 bg-muted/20 flex gap-6 text-xs text-muted-foreground">
                  <span>Total: <strong className="text-foreground">{stats.total}</strong></span>
                  <span>Signed Off: <strong className="text-emerald-700">{stats.completed}</strong></span>
                  <span>Pending: <strong className="text-amber-700">{stats.total - stats.completed}</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Fleet Count Tab */}
      {reportTab === 'fleet' && (
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-5 py-4 border-b border-border">
            <h3 className="font-heading font-semibold flex items-center gap-2"><Car className="w-4 h-4 text-primary" />Fleet Count per Project</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/40">
                  <th className="text-start p-4 font-medium text-muted-foreground">Project</th>
                  <th className="text-start p-4 font-medium text-muted-foreground">Location</th>
                  <th className="text-start p-4 font-medium text-muted-foreground">Status</th>
                  <th className="text-center p-4 font-medium text-muted-foreground">Total</th>
                  <th className="text-center p-4 font-medium text-muted-foreground">Signed Off</th>
                  <th className="text-center p-4 font-medium text-muted-foreground">Pending</th>
                  <th className="text-center p-4 font-medium text-muted-foreground">Progress</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredProjects.map(project => {
                  const stats = getProjectStats(project.id);
                  const pct = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
                  const sc = statusConfig[project.status] || statusConfig.active;
                  return (
                    <tr key={project.id} className="hover:bg-muted/20 transition-colors">
                      <td className="p-4">
                        <Link to={`/projects/${project.id}`} className="font-semibold hover:text-primary">{project.name}</Link>
                        <p className="text-xs text-muted-foreground">{project.client || 'Tamimi'}</p>
                      </td>
                      <td className="p-4 text-muted-foreground">{project.location || '—'}</td>
                      <td className="p-4"><Badge variant="outline" className={sc.class}>{sc.label}</Badge></td>
                      <td className="p-4 text-center font-bold">{stats.total}</td>
                      <td className="p-4 text-center text-emerald-700 font-semibold">{stats.completed}</td>
                      <td className="p-4 text-center text-amber-700 font-semibold">{stats.total - stats.completed}</td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-primary rounded-full" style={{ width: `${pct}%` }} />
                          </div>
                          <span className="text-xs font-medium w-8 text-end">{pct}%</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-border bg-muted/30">
                  <td colSpan={3} className="p-4 font-semibold">Total</td>
                  <td className="p-4 text-center font-bold">{filteredProjects.reduce((s, p) => s + getProjectStats(p.id).total, 0)}</td>
                  <td className="p-4 text-center text-emerald-700 font-bold">{filteredProjects.reduce((s, p) => s + getProjectStats(p.id).completed, 0)}</td>
                  <td className="p-4 text-center text-amber-700 font-bold">{filteredProjects.reduce((s, p) => { const st = getProjectStats(p.id); return s + st.total - st.completed; }, 0)}</td>
                  <td className="p-4"></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* Handover Certificates Tab */}
      {reportTab === 'certificate' && (
        <div className="space-y-4">
          {filteredProjects.filter(p => p.status === 'completed' || handovers.find(h => h.project_id === p.id)).length === 0 ? (
            <div className="text-center py-16 bg-card border border-border rounded-xl">
              <FileText className="w-10 h-10 mx-auto text-muted-foreground/30 mb-2" />
              <p className="text-muted-foreground">No finalized handover certificates yet</p>
              <p className="text-xs text-muted-foreground mt-1">Complete a project handover to generate a certificate</p>
            </div>
          ) : filteredProjects.filter(p => handovers.find(h => h.project_id === p.id)).map(project => {
            const handover = handovers.find(h => h.project_id === project.id);
            const pv = getProjectVehicles(project.id).filter(v => (handover?.vehicle_ids || []).includes(v.id));
            return (
              <div key={project.id} className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="p-5 border-b border-border flex items-center justify-between">
                  <div>
                    <h3 className="font-heading font-semibold">{project.name} — Handover Certificate</h3>
                    <p className="text-xs text-muted-foreground">{handover?.handover_date || '—'} · {project.location}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-emerald-100 text-emerald-700">Finalized</Badge>
                    <Link to={`/projects/${project.id}/handover`}><Button size="sm" variant="outline">View Full</Button></Link>
                  </div>
                </div>
                <div className="p-5 grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
                  <div><p className="text-xs text-muted-foreground">Client</p><p className="font-medium">{project.client || 'Tamimi'}</p></div>
                  <div><p className="text-xs text-muted-foreground">Contractor</p><p className="font-medium">{project.contractor || 'Arabitra'}</p></div>
                  <div><p className="text-xs text-muted-foreground">PM Name</p><p className="font-medium">{handover?.pm_name || '—'}</p></div>
                  <div><p className="text-xs text-muted-foreground">Vehicles Accepted</p><p className="font-medium">{pv.length}</p></div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Link } from 'react-router-dom';
import { Plus, Search, FolderOpen, MapPin, User, ChevronRight, Building2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';

const statusConfig = {
  active: { label: 'Active', class: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
  pending_handover: { label: 'Pending Handover', class: 'bg-amber-100 text-amber-700 border-amber-200' },
  completed: { label: 'Completed', class: 'bg-blue-100 text-blue-700 border-blue-200' },
};
