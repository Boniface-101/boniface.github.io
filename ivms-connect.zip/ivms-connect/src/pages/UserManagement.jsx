export default function UserManagement() {
  const { t } = useI18n();
  const { toast } = useToast();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('arabitra_rep');
  const [inviting, setInviting] = useState(false);

  const load = async () => {
    setLoading(true);
    const [userList, me] = await Promise.all([
      base44.entities.User.list(),
      base44.auth.me()
    ]);
    setUsers(userList);
    setCurrentUser(me);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const inviteUser = async () => {
    if (!email) {
      toast({ title: 'Please enter an email', variant: 'destructive' });
      return;
    }
    setInviting(true);
    try {
      await base44.users.inviteUser(email, role);
      toast({ title: `Invitation sent to ${email}` });
      setEmail('');
      setRole('arabitra_rep');
      load();
    } catch (err) {
      toast({ title: 'Failed to invite user', variant: 'destructive' });
    }
    setInviting(false);
  };

  const deleteUser = async (userId) => {
    try {
      await base44.entities.User.delete(userId);
      toast({ title: 'User deleted' });
      load();
    } catch {
      toast({ title: 'Failed to delete user', variant: 'destructive' });
    }
  };

  const changeRole = async (userId, newRole) => {
    await base44.entities.User.update(userId, { role: newRole });
    toast({ title: 'Role updated' });
    load();
  };

  const roleBadge = (r) => {
    const map = {
      admin: 'bg-purple-100 text-purple-700',
      arabitra_rep: 'bg-blue-100 text-blue-700',
      tamimi_rep: 'bg-amber-100 text-amber-700',
    };
    return map[r] || 'bg-muted text-muted-foreground';
  };

  if (loading) return <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" /></div>;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <Shield className="w-6 h-6 text-primary" />
        <h1 className="text-2xl font-bold font-heading">{t('user_management')}</h1>
      </div>

      <div className="bg-card rounded-xl border border-border p-5 space-y-4">
        <h3 className="font-heading font-semibold">{t('invite_user')}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="sm:col-span-1">
            <Label>Email</Label>
            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="user@example.com" className="mt-1" />
          </div>
          <div>
            <Label>{t('role')}</Label>
            <Select value={role} onValueChange={setRole}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">{t('admin')}</SelectItem>
                <SelectItem value="arabitra_rep">{t('arabitra_rep')}</SelectItem>
                <SelectItem value="tamimi_rep">{t('tamimi_rep')}</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-end">
            <Button onClick={inviteUser} disabled={inviting} className="w-full gap-1.5">
              <UserPlus className="w-4 h-4" />{inviting ? t('loading') : t('invite_user')}
            </Button>
          </div>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border overflow-hidden">
        <div className="p-4 border-b border-border flex items-center gap-2">
          <Users className="w-5 h-5 text-muted-foreground" />
          <h3 className="font-heading font-semibold">{t('users')} ({users.length})</h3>
        </div>
        <div className="divide-y divide-border">
          {users.map(u => (
            <div key={u.id} className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                  {(u.full_name || u.email || '?')[0].toUpperCase()}
                </div>
                <div>
                  <p className="font-medium text-sm">{u.full_name || u.email}</p>
                  <p className="text-xs text-muted-foreground">{u.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {currentUser?.role === 'admin' && u.id !== currentUser?.id ? (
                  <Select value={u.role} onValueChange={v => changeRole(u.id, v)}>
                    <SelectTrigger className="w-40 h-7 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">{t('admin')}</SelectItem>
                      <SelectItem value="arabitra_rep">{t('arabitra_rep')}</SelectItem>
                      <SelectItem value="tamimi_rep">{t('tamimi_rep')}</SelectItem>
                    </SelectContent>
                  </Select>
                ) : (
                  <Badge variant="outline" className={roleBadge(u.role)}>{t(u.role) || u.role}</Badge>
                )}
                {u.role !== 'admin' && u.id !== currentUser?.id && (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>{t('delete_account')}</AlertDialogTitle>
                        <AlertDialogDescription>Delete {u.full_name || u.email}? This cannot be undone.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>{t('cancel')}</AlertDialogCancel>
                        <AlertDialogAction onClick={() => deleteUser(u.id)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                          {t('confirm')}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/components/ui/use-toast';
import { Layers, Plus, Trash2, ChevronDown, X, Search } from 'lucide-react';
