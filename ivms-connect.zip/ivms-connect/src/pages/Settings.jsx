export default function Settings() {
  const { t, lang, setLang } = useI18n();
  const [darkMode, setDarkMode] = useState(document.documentElement.classList.contains('dark'));
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const toggleDark = (on) => {
    setDarkMode(on);
    document.documentElement.classList.toggle('dark', on);
    localStorage.setItem('ivms_theme', on ? 'dark' : 'light');
  };

  const handleLogout = () => {
    base44.auth.logout('/login');
  };

  return (
    <div className="max-w-lg mx-auto space-y-6">
      <h1 className="text-2xl font-bold font-heading">{t('settings')}</h1>

      {user && (
        <div className="bg-card rounded-xl border border-border p-5">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              {(user.full_name || user.email || '?')[0].toUpperCase()}
            </div>
            <div>
              <p className="font-semibold">{user.full_name || user.email}</p>
              <p className="text-sm text-muted-foreground">{user.email}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{t('role')}: {t(user.role) || user.role}</p>
            </div>
          </div>
        </div>
      )}

      <div className="bg-card rounded-xl border border-border divide-y divide-border">
        <div className="flex items-center justify-between p-5">
          <div className="flex items-center gap-3">
            <Globe className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="font-medium text-sm">{t('language')}</p>
              <p className="text-xs text-muted-foreground">{lang === 'en' ? t('english') : t('arabic')}</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={() => setLang(lang === 'en' ? 'ar' : 'en')}>
            {lang === 'en' ? 'عربي' : 'English'}
          </Button>
        </div>

        <div className="flex items-center justify-between p-5">
          <div className="flex items-center gap-3">
            <Moon className="w-5 h-5 text-muted-foreground" />
            <div>
              <p className="font-medium text-sm">{t('dark_mode')}</p>
            </div>
          </div>
          <Switch checked={darkMode} onCheckedChange={toggleDark} />
        </div>

        <div className="p-5">
          <Button variant="outline" className="w-full gap-1.5" onClick={handleLogout}>
            <LogOut className="w-4 h-4" />{t('logout')}
          </Button>
        </div>

        {user?.role !== 'admin' && (<div className="p-5">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" className="w-full gap-1.5">
                <Trash2 className="w-4 h-4" />{t('delete_account')}
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t('delete_account')}</AlertDialogTitle>
                <AlertDialogDescription>{t('delete_account_confirm')}</AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t('cancel')}</AlertDialogCancel>
                <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  {t('confirm')}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>)}
      </div>
    </div>
  );
}
import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { UserPlus, Trash2, Users, Shield } from 'lucide-react';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger
} from '@/components/ui/alert-dialog';
